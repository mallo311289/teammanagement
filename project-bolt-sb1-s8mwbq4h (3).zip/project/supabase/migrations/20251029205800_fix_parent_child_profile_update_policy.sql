/*
  # Fix Parent Child Profile Update Policy

  ## Overview
  Fixes the RLS policy for parent updates to properly allow parents to update their children's profiles.
  The previous policy had a WITH CHECK clause that prevented updates from working correctly.

  ## Problem
  - The existing policy's WITH CHECK clause validates `parent_id = auth.uid()` on the updated row
  - This prevents updates because it requires parent_id to remain unchanged
  - Parents need to update fields like avatar_url, date_of_birth, and phone

  ## Solution
  - Drop the existing parent update policy
  - Create new policy with proper USING and WITH CHECK clauses
  - USING: Verify parent owns the record (parent_id = auth.uid())
  - WITH CHECK: Ensure parent_id doesn't change during update
  - Create trigger to enforce field-level restrictions for parents

  ## Security Changes
  
  ### Modified Policies
  - Drop existing "Parents can update their child's profile" policy
  - Create new "Parents can update their children's profiles" policy with correct validation
  
  ### New Triggers
  - Create trigger to restrict parents to only updating: avatar_url, date_of_birth, phone
  - Managers retain full update permissions for all fields

  ## Important Notes
  - Parents can only update specific fields: avatar_url, date_of_birth, phone
  - Parents cannot change: full_name, jersey_number, position, parent_id, email
  - Managers have unrestricted update access
  - The parent_id field cannot be changed by parents (prevents ownership hijacking)
*/

-- Drop the existing parent update policy
DROP POLICY IF EXISTS "Parents can update their child's profile" ON players;

-- Create new policy: Parents can update their children's profiles
-- USING: Check if the parent owns this player record
-- WITH CHECK: Ensure the parent_id doesn't change (prevent ownership transfer)
CREATE POLICY "Parents can update their children's profiles"
  ON players FOR UPDATE
  TO authenticated
  USING (
    parent_id = auth.uid()
  )
  WITH CHECK (
    parent_id = auth.uid()
    AND (
      -- Ensure parent_id is not being changed
      (SELECT parent_id FROM players WHERE id = players.id) = auth.uid()
    )
  );

-- Create function to validate parent updates
CREATE OR REPLACE FUNCTION validate_parent_player_update()
RETURNS TRIGGER AS $$
BEGIN
  -- If the user is a manager, allow all updates
  IF EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'manager'
  ) THEN
    RETURN NEW;
  END IF;

  -- If the user is a parent, restrict field updates
  IF EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'parent'
  ) THEN
    -- Parents can only update these fields: avatar_url, date_of_birth, phone
    -- Prevent changes to other fields by reverting them to OLD values
    NEW.full_name = OLD.full_name;
    NEW.jersey_number = OLD.jersey_number;
    NEW.position = OLD.position;
    NEW.email = OLD.email;
    NEW.parent_id = OLD.parent_id;
    NEW.created_by = OLD.created_by;
    NEW.created_at = OLD.created_at;
    
    RETURN NEW;
  END IF;

  -- If neither manager nor parent, reject the update
  RAISE EXCEPTION 'Unauthorized update attempt';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS validate_parent_player_update_trigger ON players;

-- Create trigger to enforce field-level restrictions
CREATE TRIGGER validate_parent_player_update_trigger
  BEFORE UPDATE ON players
  FOR EACH ROW
  EXECUTE FUNCTION validate_parent_player_update();