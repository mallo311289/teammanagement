/*
  # Create Media Storage and Table

  1. New Storage Buckets
    - `media` - For storing team photos and videos
  
  2. New Tables
    - `media_files`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to profiles)
      - `file_name` (text)
      - `file_path` (text) - storage path
      - `file_type` (text) - 'image' or 'video'
      - `file_size` (bigint) - size in bytes
      - `mime_type` (text)
      - `caption` (text, optional)
      - `created_at` (timestamp)
  
  3. Security
    - Enable RLS on media_files table
    - All authenticated users can view media
    - All authenticated users can upload media
    - Users can only delete their own uploads
    - Storage policies for public access to media files
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('media', 'media', true)
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS media_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_path text NOT NULL,
  file_type text NOT NULL CHECK (file_type IN ('image', 'video')),
  file_size bigint NOT NULL,
  mime_type text NOT NULL,
  caption text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS media_files_user_id_idx ON media_files(user_id);
CREATE INDEX IF NOT EXISTS media_files_created_at_idx ON media_files(created_at DESC);
CREATE INDEX IF NOT EXISTS media_files_file_type_idx ON media_files(file_type);

ALTER TABLE media_files ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view media files"
  ON media_files FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can upload media"
  ON media_files FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own media"
  ON media_files FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own media"
  ON media_files FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Anyone can view media bucket"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'media');

CREATE POLICY "Authenticated users can upload to media bucket"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'media');

CREATE POLICY "Users can update own files in media bucket"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'media' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete own files in media bucket"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'media' AND auth.uid()::text = (storage.foldername(name))[1]);
