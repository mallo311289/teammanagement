/*
  # Fix Security and Performance Issues

  ## Overview
  Addresses multiple security and performance issues identified by Supabase:
  1. Missing indexes on foreign keys
  2. Inefficient RLS policies (auth function calls)
  3. Unused indexes
  4. Multiple permissive policies causing OR conditions

  ## Changes

  ### 1. Add Missing Foreign Key Indexes
  - announcements.user_id
  - match_lineups.created_by
  - media_files.user_id
  - players.created_by

  ### 2. Remove Unused Indexes
  - chat_messages_user_id_idx (not used in queries)
  - availability_player_id_idx (not used in queries)
  - availability_event_player_idx (not used in queries)

  ### 3. Optimize RLS Policies
  Replace auth function calls with subqueries for better performance:
  - All policies using auth.uid() → (SELECT auth.uid())
  - Prevents re-evaluation for each row

  ### 4. Consolidate Duplicate Permissive Policies
  Replace multiple OR policies with single comprehensive policies:
  - availability table (DELETE, INSERT, UPDATE)
  - chat_messages table (DELETE)
  - profiles table (UPDATE)

  ## Performance Impact
  - Foreign key indexes: Significantly improves JOIN performance
  - RLS optimization: Reduces function calls from O(n) to O(1)
  - Policy consolidation: Cleaner execution plans
*/

-- ============================================================================
-- 1. ADD MISSING FOREIGN KEY INDEXES
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_announcements_user_id
  ON announcements(user_id);

CREATE INDEX IF NOT EXISTS idx_match_lineups_created_by
  ON match_lineups(created_by);

CREATE INDEX IF NOT EXISTS idx_media_files_user_id
  ON media_files(user_id);

CREATE INDEX IF NOT EXISTS idx_players_created_by
  ON players(created_by);

-- ============================================================================
-- 2. REMOVE UNUSED INDEXES
-- ============================================================================

DROP INDEX IF EXISTS chat_messages_user_id_idx;
DROP INDEX IF EXISTS availability_player_id_idx;
DROP INDEX IF EXISTS availability_event_player_idx;

-- ============================================================================
-- 3. OPTIMIZE RLS POLICIES - CHAT MESSAGES
-- ============================================================================

-- Drop existing duplicate DELETE policies
DROP POLICY IF EXISTS "Users can delete own messages" ON chat_messages;
DROP POLICY IF EXISTS "Managers can delete any message" ON chat_messages;

-- Create consolidated optimized DELETE policy
CREATE POLICY "Users can delete messages"
  ON chat_messages FOR DELETE
  TO authenticated
  USING (
    (SELECT auth.uid()) = user_id
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  );

-- Optimize existing SELECT policy
DROP POLICY IF EXISTS "All users can view messages" ON chat_messages;
CREATE POLICY "All users can view messages"
  ON chat_messages FOR SELECT
  TO authenticated
  USING (true);

-- Optimize existing INSERT policy
DROP POLICY IF EXISTS "Users can create messages" ON chat_messages;
CREATE POLICY "Users can create messages"
  ON chat_messages FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT auth.uid()) = user_id);

-- ============================================================================
-- 4. OPTIMIZE RLS POLICIES - AVAILABILITY
-- ============================================================================

-- Drop existing duplicate policies
DROP POLICY IF EXISTS "Users can delete availability" ON availability;
DROP POLICY IF EXISTS "Users can delete own availability" ON availability;
DROP POLICY IF EXISTS "Users can insert availability" ON availability;
DROP POLICY IF EXISTS "Users can insert own availability" ON availability;
DROP POLICY IF EXISTS "Users can update availability" ON availability;
DROP POLICY IF EXISTS "Users can update own availability" ON availability;

-- Recreate with optimized single policies
CREATE POLICY "Users can view availability"
  ON availability FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage own availability"
  ON availability FOR INSERT
  TO authenticated
  WITH CHECK (
    (SELECT auth.uid()) = user_id
    OR (SELECT auth.uid()) = player_id
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND player_id::text = ANY(profiles.parent_of)
    )
  );

CREATE POLICY "Users can update own availability"
  ON availability FOR UPDATE
  TO authenticated
  USING (
    (SELECT auth.uid()) = user_id
    OR (SELECT auth.uid()) = player_id
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND availability.player_id::text = ANY(profiles.parent_of)
    )
  )
  WITH CHECK (
    (SELECT auth.uid()) = user_id
    OR (SELECT auth.uid()) = player_id
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND availability.player_id::text = ANY(profiles.parent_of)
    )
  );

CREATE POLICY "Users can delete own availability"
  ON availability FOR DELETE
  TO authenticated
  USING (
    (SELECT auth.uid()) = user_id
    OR (SELECT auth.uid()) = player_id
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND availability.player_id::text = ANY(profiles.parent_of)
    )
  );

-- ============================================================================
-- 5. OPTIMIZE RLS POLICIES - PROFILES
-- ============================================================================

-- Drop existing duplicate UPDATE policies
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Parents can update their child profile" ON profiles;

-- Create consolidated optimized UPDATE policy
CREATE POLICY "Users can update profiles"
  ON profiles FOR UPDATE
  TO authenticated
  USING (
    (SELECT auth.uid()) = id
    OR (SELECT auth.uid())::text = ANY(parent_of)
  )
  WITH CHECK (
    (SELECT auth.uid()) = id
    OR (SELECT auth.uid())::text = ANY(parent_of)
  );

-- Optimize existing SELECT policy
DROP POLICY IF EXISTS "Users can view all profiles" ON profiles;
CREATE POLICY "Users can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

-- Optimize existing INSERT policy
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT auth.uid()) = id);

-- ============================================================================
-- 6. OPTIMIZE OTHER RLS POLICIES
-- ============================================================================

-- Events table
DROP POLICY IF EXISTS "All users can view events" ON events;
CREATE POLICY "All users can view events"
  ON events FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Managers can create events" ON events;
CREATE POLICY "Managers can create events"
  ON events FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  );

DROP POLICY IF EXISTS "Managers can update events" ON events;
CREATE POLICY "Managers can update events"
  ON events FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  );

DROP POLICY IF EXISTS "Managers can delete events" ON events;
CREATE POLICY "Managers can delete events"
  ON events FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  );

-- Announcements table
DROP POLICY IF EXISTS "All users can view announcements" ON announcements;
CREATE POLICY "All users can view announcements"
  ON announcements FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Managers can create announcements" ON announcements;
CREATE POLICY "Managers can create announcements"
  ON announcements FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  );

DROP POLICY IF EXISTS "Managers can update announcements" ON announcements;
CREATE POLICY "Managers can update announcements"
  ON announcements FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  );

DROP POLICY IF EXISTS "Managers can delete announcements" ON announcements;
CREATE POLICY "Managers can delete announcements"
  ON announcements FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  );

-- Notifications table
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;
CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING ((SELECT auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;
CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING ((SELECT auth.uid()) = user_id)
  WITH CHECK ((SELECT auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can delete own notifications" ON notifications;
CREATE POLICY "Users can delete own notifications"
  ON notifications FOR DELETE
  TO authenticated
  USING ((SELECT auth.uid()) = user_id);

-- Players table
DROP POLICY IF EXISTS "All users can view players" ON players;
CREATE POLICY "All users can view players"
  ON players FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Managers can create players" ON players;
CREATE POLICY "Managers can create players"
  ON players FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  );

DROP POLICY IF EXISTS "Managers can update players" ON players;
CREATE POLICY "Managers can update players"
  ON players FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  );

DROP POLICY IF EXISTS "Managers can delete players" ON players;
CREATE POLICY "Managers can delete players"
  ON players FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  );

-- Media files table
DROP POLICY IF EXISTS "All users can view media files" ON media_files;
CREATE POLICY "All users can view media files"
  ON media_files FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "Users can upload media files" ON media_files;
CREATE POLICY "Users can upload media files"
  ON media_files FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT auth.uid()) = user_id);

DROP POLICY IF EXISTS "Managers can delete media files" ON media_files;
CREATE POLICY "Managers can delete media files"
  ON media_files FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = (SELECT auth.uid())
      AND profiles.role = 'manager'
    )
  );
