/*
  # Add Missing Foreign Key Indexes

  ## Overview
  Adds indexes to foreign key columns that are currently unindexed, improving
  query performance for JOIN operations and foreign key lookups.

  ## Performance Impact
  - Significantly improves JOIN performance on these tables
  - Speeds up cascading deletes and updates
  - Reduces table scan costs for foreign key constraints
  - Minimal storage overhead for the indexes

  ## Changes
  1. Add index on announcements.user_id
  2. Add index on match_lineups.created_by
  3. Add index on media_files.user_id
  4. Add index on players.created_by

  ## Security
  - No RLS changes required
  - Indexes are performance optimizations only
  - Does not affect data access permissions
*/

-- Add index for announcements.user_id foreign key
CREATE INDEX IF NOT EXISTS idx_announcements_user_id 
  ON announcements(user_id);

-- Add index for match_lineups.created_by foreign key
CREATE INDEX IF NOT EXISTS idx_match_lineups_created_by 
  ON match_lineups(created_by);

-- Add index for media_files.user_id foreign key
CREATE INDEX IF NOT EXISTS idx_media_files_user_id 
  ON media_files(user_id);

-- Add index for players.created_by foreign key
CREATE INDEX IF NOT EXISTS idx_players_created_by 
  ON players(created_by);
