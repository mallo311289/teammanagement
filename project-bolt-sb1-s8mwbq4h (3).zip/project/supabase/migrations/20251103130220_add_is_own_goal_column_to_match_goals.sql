/*
  # Add is_own_goal Column to match_goals Table

  1. Changes
    - Add `is_own_goal` boolean field to `match_goals` table
    - Defaults to false
    - Allows tracking of own goals separately from regular goals

  2. Notes
    - Own goals don't count toward player's goal statistics
    - This fixes the "column mg.own_goal does not exist" error
*/

-- Add is_own_goal field to match_goals table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'match_goals' AND column_name = 'is_own_goal'
  ) THEN
    ALTER TABLE match_goals ADD COLUMN is_own_goal boolean DEFAULT false;
  END IF;
END $$;
