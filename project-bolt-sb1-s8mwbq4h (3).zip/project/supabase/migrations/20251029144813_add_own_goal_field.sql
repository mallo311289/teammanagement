/*
  # Add Own Goal Field to Match Goals

  1. Changes
    - Add `is_own_goal` boolean field to `match_goals` table
    - Defaults to false
    - Allows tracking of own goals separately from regular goals

  2. Notes
    - Own goals don't count toward player's goal statistics
    - Own goals are attributed to opposition players in match context
*/

-- Add is_own_goal field to match_goals table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'match_goals' AND column_name = 'is_own_goal'
  ) THEN
    ALTER TABLE match_goals ADD COLUMN is_own_goal boolean DEFAULT false;
  END IF;
END $$;
