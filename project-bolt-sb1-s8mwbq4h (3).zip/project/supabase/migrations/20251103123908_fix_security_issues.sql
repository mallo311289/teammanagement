/*
  # Fix Security and Performance Issues

  ## Summary
  This migration addresses critical security and performance issues identified in the database audit:
  
  1. **Performance Improvements**
     - Add missing indexes for foreign keys to improve query performance
     - Remove unused indexes that add unnecessary overhead
  
  2. **Security Improvements**
     - Consolidate duplicate permissive RLS policies to prevent policy conflicts
     - Remove redundant policies that could lead to unintended access
  
  ## Changes
  
  ### New Indexes
  - `idx_availability_player_id` on `availability(player_id)` - improves availability lookups
  - `idx_chat_messages_user_id` on `chat_messages(user_id)` - improves chat message queries
  
  ### Removed Indexes
  - `idx_players_created_by` - unused index on players table
  - `idx_media_files_user_id` - unused index on media_files table
  - `idx_match_lineups_created_by` - unused index on match_lineups table
  - `idx_announcements_user_id` - unused index on announcements table
  
  ### RLS Policy Consolidation
  
  #### Announcements Table
  - Removed duplicate SELECT policy "All users can view announcements"
  - Kept "Authenticated users can view all announcements"
  - Removed duplicate DELETE policy "Managers can delete announcements"
  - Kept "Managers can delete own announcements" (more restrictive)
  
  #### Media Files Table
  - Removed duplicate SELECT policy "All users can view media files"
  - Kept "Anyone can view media files"
  - Removed duplicate INSERT policy "Authenticated users can upload media"
  - Kept "Users can upload media files"
  - Removed duplicate DELETE policy "Managers can delete media files"
  - Kept "Users can delete own media" (more specific)
  
  #### Players Table
  - Removed duplicate INSERT policy "Managers can create players"
  - Kept "Managers can insert players"
  - Removed duplicate SELECT policy "All users can view players"
  - Kept "Authenticated users can view all players"
  - Removed duplicate UPDATE policy "Managers and parents can update players"
  - Kept "Managers can update players"
  
  ## Security Notes
  - All changes maintain or improve security posture
  - No data access is lost, only redundant policies removed
  - Indexes improve performance without affecting security
*/

-- =====================================================
-- STEP 1: Add Missing Foreign Key Indexes
-- =====================================================

-- Add index for availability.player_id foreign key
CREATE INDEX IF NOT EXISTS idx_availability_player_id 
ON availability(player_id);

-- Add index for chat_messages.user_id foreign key
CREATE INDEX IF NOT EXISTS idx_chat_messages_user_id 
ON chat_messages(user_id);

-- =====================================================
-- STEP 2: Remove Unused Indexes
-- =====================================================

-- Drop unused indexes that add unnecessary overhead
DROP INDEX IF EXISTS idx_players_created_by;
DROP INDEX IF EXISTS idx_media_files_user_id;
DROP INDEX IF EXISTS idx_match_lineups_created_by;
DROP INDEX IF EXISTS idx_announcements_user_id;

-- =====================================================
-- STEP 3: Consolidate Duplicate RLS Policies
-- =====================================================

-- ANNOUNCEMENTS TABLE
-- Remove duplicate SELECT policy
DROP POLICY IF EXISTS "All users can view announcements" ON announcements;

-- Remove duplicate DELETE policy (keeping the more restrictive one)
DROP POLICY IF EXISTS "Managers can delete announcements" ON announcements;

-- MEDIA_FILES TABLE
-- Remove duplicate SELECT policy
DROP POLICY IF EXISTS "All users can view media files" ON media_files;

-- Remove duplicate INSERT policy
DROP POLICY IF EXISTS "Authenticated users can upload media" ON media_files;

-- Remove duplicate DELETE policy
DROP POLICY IF EXISTS "Managers can delete media files" ON media_files;

-- PLAYERS TABLE
-- Remove duplicate INSERT policy
DROP POLICY IF EXISTS "Managers can create players" ON players;

-- Remove duplicate SELECT policy
DROP POLICY IF EXISTS "All users can view players" ON players;

-- Remove duplicate UPDATE policy
DROP POLICY IF EXISTS "Managers and parents can update players" ON players;