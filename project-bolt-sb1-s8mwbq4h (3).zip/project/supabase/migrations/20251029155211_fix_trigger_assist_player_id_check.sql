/*
  # Fix Trigger Function for assist_player_id Access

  1. Problem
    - The update_player_statistics() function references NEW.assist_player_id and OLD.assist_player_id
    - This function is used by both match_goals and match_participants tables
    - match_participants doesn't have assist_player_id field, causing error
    - PostgreSQL evaluates column references even in conditional branches

  2. Solution
    - Use CASE statement within the PERFORM to avoid referencing non-existent columns
    - Restructure function to handle assist_player_id only for match_goals table
    - Use dynamic approach that checks table name first

  3. Implementation
    - Replace function with table-aware logic
    - Only attempt to access assist_player_id when coming from match_goals
*/

CREATE OR REPLACE FUNCTION update_player_statistics()
RETURNS TRIGGER AS $$
DECLARE
  assist_id uuid;
BEGIN
  -- Recalculate stats for the affected player(s)
  IF TG_OP = 'DELETE' THEN
    PERFORM recalculate_player_stats(OLD.player_id);
    
    -- Only check assist_player_id if this is from match_goals table
    IF TG_TABLE_NAME = 'match_goals' THEN
      -- Safely extract assist_player_id using hstore
      SELECT (hstore(OLD.*) -> 'assist_player_id')::uuid INTO assist_id;
      IF assist_id IS NOT NULL THEN
        PERFORM recalculate_player_stats(assist_id);
      END IF;
    END IF;
  ELSE
    PERFORM recalculate_player_stats(NEW.player_id);
    
    -- Only check assist_player_id if this is from match_goals table
    IF TG_TABLE_NAME = 'match_goals' THEN
      -- Safely extract assist_player_id using hstore
      SELECT (hstore(NEW.*) -> 'assist_player_id')::uuid INTO assist_id;
      IF assist_id IS NOT NULL THEN
        PERFORM recalculate_player_stats(assist_id);
      END IF;
    END IF;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;
