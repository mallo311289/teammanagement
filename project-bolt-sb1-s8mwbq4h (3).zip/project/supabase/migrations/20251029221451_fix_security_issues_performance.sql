/*
  # Fix Security Issues and Performance Optimization

  ## Changes Made

  ### 1. Missing Index
    - Add index on `chat_messages.user_id` foreign key for better query performance

  ### 2. RLS Policy Optimization
    - Replace all `auth.uid()` with `(select auth.uid())` in RLS policies
    - This prevents re-evaluation of auth function for each row, improving performance at scale

  ### 3. Unused Index Removal
    - Remove unused indexes to improve write performance and reduce storage

  ### 4. Multiple Permissive Policies Fix
    - Consolidate multiple UPDATE policies on players table into single optimized policy

  ### 5. Function Security
    - Add SECURITY DEFINER and set search_path to all functions
    - Prevents search_path injection vulnerabilities

  ## Security Notes
  - All changes maintain existing access controls
  - Performance improved without changing security model
*/

-- ============================================================
-- 1. ADD MISSING INDEX
-- ============================================================

CREATE INDEX IF NOT EXISTS chat_messages_user_id_idx ON chat_messages(user_id);

-- ============================================================
-- 2. OPTIMIZE RLS POLICIES - DROP AND RECREATE
-- ============================================================

-- PROFILES TABLE
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Parents can update their child profile" ON profiles;

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = id)
  WITH CHECK ((select auth.uid()) = id);

CREATE POLICY "Parents can update their child profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (
    (select auth.uid())::text = ANY(parent_of)
  )
  WITH CHECK (
    (select auth.uid())::text = ANY(parent_of)
  );

-- EVENTS TABLE
DROP POLICY IF EXISTS "Managers can create events" ON events;
DROP POLICY IF EXISTS "Managers can update events" ON events;
DROP POLICY IF EXISTS "Managers can delete events" ON events;

CREATE POLICY "Managers can create events"
  ON events FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can update events"
  ON events FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can delete events"
  ON events FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

-- AVAILABILITY TABLE
DROP POLICY IF EXISTS "Users can insert own availability" ON availability;
DROP POLICY IF EXISTS "Users can update own availability" ON availability;
DROP POLICY IF EXISTS "Users can delete own availability" ON availability;

CREATE POLICY "Users can insert own availability"
  ON availability FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own availability"
  ON availability FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own availability"
  ON availability FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- CHAT_MESSAGES TABLE
DROP POLICY IF EXISTS "Users can create messages" ON chat_messages;
DROP POLICY IF EXISTS "Users can delete own messages" ON chat_messages;

CREATE POLICY "Users can create messages"
  ON chat_messages FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own messages"
  ON chat_messages FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- PLAYERS TABLE - CONSOLIDATE MULTIPLE UPDATE POLICIES
DROP POLICY IF EXISTS "Managers can insert players" ON players;
DROP POLICY IF EXISTS "Managers can delete players" ON players;
DROP POLICY IF EXISTS "Managers can update all player fields" ON players;
DROP POLICY IF EXISTS "Parents can update their children's profiles" ON players;

CREATE POLICY "Managers can insert players"
  ON players FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can delete players"
  ON players FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

-- SINGLE CONSOLIDATED UPDATE POLICY FOR PLAYERS
CREATE POLICY "Managers and parents can update players"
  ON players FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
    OR
    parent_id = (select auth.uid())
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
    OR
    parent_id = (select auth.uid())
  );

-- MATCH_PARTICIPANTS TABLE
DROP POLICY IF EXISTS "Managers can insert match participants" ON match_participants;
DROP POLICY IF EXISTS "Managers can update match participants" ON match_participants;
DROP POLICY IF EXISTS "Managers can delete match participants" ON match_participants;

CREATE POLICY "Managers can insert match participants"
  ON match_participants FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can update match participants"
  ON match_participants FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can delete match participants"
  ON match_participants FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

-- MATCH_GOALS TABLE
DROP POLICY IF EXISTS "Managers can insert match goals" ON match_goals;
DROP POLICY IF EXISTS "Managers can update match goals" ON match_goals;
DROP POLICY IF EXISTS "Managers can delete match goals" ON match_goals;

CREATE POLICY "Managers can insert match goals"
  ON match_goals FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can update match goals"
  ON match_goals FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can delete match goals"
  ON match_goals FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

-- MATCH_LINEUPS TABLE
DROP POLICY IF EXISTS "Managers can insert lineups" ON match_lineups;
DROP POLICY IF EXISTS "Managers can update lineups" ON match_lineups;
DROP POLICY IF EXISTS "Managers can delete lineups" ON match_lineups;

CREATE POLICY "Managers can insert lineups"
  ON match_lineups FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can update lineups"
  ON match_lineups FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can delete lineups"
  ON match_lineups FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

-- ANNOUNCEMENTS TABLE
DROP POLICY IF EXISTS "Managers can create announcements" ON announcements;
DROP POLICY IF EXISTS "Managers can delete own announcements" ON announcements;

CREATE POLICY "Managers can create announcements"
  ON announcements FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can delete own announcements"
  ON announcements FOR DELETE
  TO authenticated
  USING (
    (select auth.uid()) = user_id AND
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

-- NOTIFICATIONS TABLE
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can delete own notifications" ON notifications;

CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own notifications"
  ON notifications FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- MEDIA_FILES TABLE
DROP POLICY IF EXISTS "Authenticated users can upload media" ON media_files;
DROP POLICY IF EXISTS "Users can update own media" ON media_files;
DROP POLICY IF EXISTS "Users can delete own media" ON media_files;

CREATE POLICY "Authenticated users can upload media"
  ON media_files FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own media"
  ON media_files FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own media"
  ON media_files FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- PLAYER_STATS TABLE
DROP POLICY IF EXISTS "Managers can insert player stats" ON player_stats;
DROP POLICY IF EXISTS "Managers can update player stats" ON player_stats;

CREATE POLICY "Managers can insert player stats"
  ON player_stats FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

CREATE POLICY "Managers can update player stats"
  ON player_stats FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = (select auth.uid()) 
      AND role = 'manager'
    )
  );

-- ============================================================
-- 3. REMOVE UNUSED INDEXES
-- ============================================================

DROP INDEX IF EXISTS players_created_by_idx;
DROP INDEX IF EXISTS notifications_is_read_idx;
DROP INDEX IF EXISTS notifications_created_at_idx;
DROP INDEX IF EXISTS media_files_user_id_idx;
DROP INDEX IF EXISTS media_files_file_type_idx;
DROP INDEX IF EXISTS match_lineups_created_by_idx;
DROP INDEX IF EXISTS announcements_user_id_idx;

-- ============================================================
-- 4. FIX FUNCTION SECURITY - ADD SECURITY DEFINER AND SEARCH_PATH
-- ============================================================

-- Function: create_user_with_profile
CREATE OR REPLACE FUNCTION create_user_with_profile(
  user_email text,
  user_password text,
  user_full_name text,
  user_role text DEFAULT 'player'
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  new_user_id uuid;
BEGIN
  INSERT INTO auth.users (
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    created_at,
    updated_at,
    role
  )
  VALUES (
    user_email,
    crypt(user_password, gen_salt('bf')),
    now(),
    jsonb_build_object('provider', 'email', 'providers', ARRAY['email']),
    jsonb_build_object('full_name', user_full_name),
    now(),
    now(),
    'authenticated'
  )
  RETURNING id INTO new_user_id;

  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (new_user_id, user_email, user_full_name, user_role);

  RETURN new_user_id;
END;
$$;

-- Function: reset_all_player_stats
CREATE OR REPLACE FUNCTION reset_all_player_stats()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE player_stats
  SET 
    matches_played = 0,
    goals = 0,
    assists = 0,
    yellow_cards = 0,
    red_cards = 0,
    minutes_played = 0;
END;
$$;

-- Function: recalculate_player_stats
CREATE OR REPLACE FUNCTION recalculate_player_stats(p_player_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_matches_played integer;
  v_goals integer;
  v_assists integer;
  v_yellow_cards integer;
  v_red_cards integer;
  v_minutes_played integer;
BEGIN
  SELECT 
    COUNT(DISTINCT mp.event_id),
    COALESCE(SUM(CASE WHEN mg.own_goal = false THEN 1 ELSE 0 END), 0),
    COALESCE(SUM(CASE WHEN mg.assist_player_id = p_player_id THEN 1 ELSE 0 END), 0),
    COALESCE(SUM(mp.yellow_cards), 0),
    COALESCE(SUM(mp.red_cards), 0),
    COALESCE(SUM(mp.minutes_played), 0)
  INTO 
    v_matches_played,
    v_goals,
    v_assists,
    v_yellow_cards,
    v_red_cards,
    v_minutes_played
  FROM match_participants mp
  LEFT JOIN match_goals mg ON mg.player_id = p_player_id
  WHERE mp.player_id = p_player_id;

  UPDATE player_stats
  SET 
    matches_played = v_matches_played,
    goals = v_goals,
    assists = v_assists,
    yellow_cards = v_yellow_cards,
    red_cards = v_red_cards,
    minutes_played = v_minutes_played,
    updated_at = now()
  WHERE player_id = p_player_id;
END;
$$;

-- Function: update_player_statistics
CREATE OR REPLACE FUNCTION update_player_statistics()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  PERFORM recalculate_player_stats(NEW.player_id);
  RETURN NEW;
END;
$$;

-- Function: update_player_statistics_for_goals
CREATE OR REPLACE FUNCTION update_player_statistics_for_goals()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    PERFORM recalculate_player_stats(OLD.player_id);
    IF OLD.assist_player_id IS NOT NULL THEN
      PERFORM recalculate_player_stats(OLD.assist_player_id);
    END IF;
    RETURN OLD;
  ELSE
    PERFORM recalculate_player_stats(NEW.player_id);
    IF NEW.assist_player_id IS NOT NULL THEN
      PERFORM recalculate_player_stats(NEW.assist_player_id);
    END IF;
    RETURN NEW;
  END IF;
END;
$$;

-- Function: update_player_statistics_for_participants
CREATE OR REPLACE FUNCTION update_player_statistics_for_participants()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    PERFORM recalculate_player_stats(OLD.player_id);
    RETURN OLD;
  ELSE
    PERFORM recalculate_player_stats(NEW.player_id);
    RETURN NEW;
  END IF;
END;
$$;

-- Function: validate_parent_player_update
CREATE OR REPLACE FUNCTION validate_parent_player_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  is_manager boolean;
  is_parent boolean;
BEGIN
  SELECT role = 'manager' INTO is_manager
  FROM profiles
  WHERE id = (select auth.uid());

  IF is_manager THEN
    RETURN NEW;
  END IF;

  SELECT parent_id = (select auth.uid()) INTO is_parent
  FROM players
  WHERE id = NEW.id;

  IF NOT is_parent THEN
    RAISE EXCEPTION 'Not authorized to update this player';
  END IF;

  RETURN NEW;
END;
$$;

-- Function: notify_new_announcement
CREATE OR REPLACE FUNCTION notify_new_announcement()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO notifications (user_id, type, title, message, related_id)
  SELECT 
    id,
    'announcement',
    'New Announcement',
    NEW.message,
    NEW.id
  FROM profiles
  WHERE id != NEW.user_id;
  
  RETURN NEW;
END;
$$;

-- Function: notify_new_event
CREATE OR REPLACE FUNCTION notify_new_event()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO notifications (user_id, type, title, message, related_id)
  SELECT 
    id,
    'event',
    'New ' || NEW.event_type || ' scheduled',
    NEW.title || ' on ' || to_char(NEW.event_date, 'Mon DD at HH24:MI'),
    NEW.id
  FROM profiles
  WHERE role IN ('player', 'parent');
  
  RETURN NEW;
END;
$$;

-- Function: notify_new_message
CREATE OR REPLACE FUNCTION notify_new_message()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO notifications (user_id, type, title, message, related_id)
  SELECT 
    id,
    'chat',
    (SELECT full_name FROM profiles WHERE id = NEW.user_id) || ' sent a message',
    NEW.message,
    NEW.id
  FROM profiles
  WHERE id != NEW.user_id;
  
  RETURN NEW;
END;
$$;

-- Timestamp update functions
CREATE OR REPLACE FUNCTION update_players_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION update_match_participants_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION update_match_goals_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION update_match_lineups_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;