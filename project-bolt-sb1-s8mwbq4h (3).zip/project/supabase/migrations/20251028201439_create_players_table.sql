/*
  # Create Players Table

  ## Overview
  Creates a table to store player information for the team management system.

  ## New Tables
  
  ### `players`
  - `id` (uuid, primary key) - Unique identifier for each player
  - `full_name` (text, required) - Player's full name
  - `jersey_number` (integer, optional) - Player's jersey/shirt number
  - `position` (text, optional) - Player's position (e.g., Goalkeeper, Defender, Midfielder, Forward)
  - `date_of_birth` (date, optional) - Player's date of birth
  - `email` (text, optional) - Player's email address
  - `phone` (text, optional) - Player's phone number
  - `parent_id` (uuid, optional) - Reference to parent's profile
  - `avatar_url` (text, optional) - URL to player's profile picture
  - `created_by` (uuid, required) - Manager who added the player
  - `created_at` (timestamptz) - Timestamp of record creation
  - `updated_at` (timestamptz) - Timestamp of last update

  ## Security
  - Enable RLS on players table
  - Authenticated users can view all players
  - Only managers can insert new players
  - Only managers can update player records
  - Only managers can delete players

  ## Indexes
  - Index on `created_by` for efficient queries
  - Index on `parent_id` for parent-player relationships
*/

-- Create players table
CREATE TABLE IF NOT EXISTS players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  jersey_number integer,
  position text,
  date_of_birth date,
  email text,
  phone text,
  parent_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  avatar_url text,
  created_by uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add check constraint for position
ALTER TABLE players ADD CONSTRAINT players_position_check 
  CHECK (position IS NULL OR position IN ('Goalkeeper', 'Defender', 'Midfielder', 'Forward'));

-- Add check constraint for jersey number
ALTER TABLE players ADD CONSTRAINT players_jersey_number_check 
  CHECK (jersey_number IS NULL OR (jersey_number > 0 AND jersey_number < 100));

-- Create indexes
CREATE INDEX IF NOT EXISTS players_created_by_idx ON players(created_by);
CREATE INDEX IF NOT EXISTS players_parent_id_idx ON players(parent_id);

-- Enable RLS
ALTER TABLE players ENABLE ROW LEVEL SECURITY;

-- RLS Policies

-- Authenticated users can view all players
CREATE POLICY "Authenticated users can view all players"
  ON players FOR SELECT
  TO authenticated
  USING (true);

-- Only managers can insert players
CREATE POLICY "Managers can insert players"
  ON players FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

-- Only managers can update players
CREATE POLICY "Managers can update players"
  ON players FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

-- Only managers can delete players
CREATE POLICY "Managers can delete players"
  ON players FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_players_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update updated_at
CREATE TRIGGER players_updated_at_trigger
  BEFORE UPDATE ON players
  FOR EACH ROW
  EXECUTE FUNCTION update_players_updated_at();
