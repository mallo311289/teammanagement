/*
  # Fix update_player_statistics Trigger Function

  1. Problem
    - The function is used by triggers on both match_goals and match_participants tables
    - When triggered from match_participants, NEW.assist_player_id doesn't exist
    - This causes error: "record *new* has no field 'assist_player_id'"

  2. Solution
    - Check TG_TABLE_NAME before accessing assist_player_id
    - Only access assist_player_id when the trigger comes from match_goals table

  3. Changes
    - Update update_player_statistics() function to check table context
*/

CREATE OR REPLACE FUNCTION update_player_statistics()
RETURNS TRIGGER AS $$
BEGIN
  -- Recalculate stats for the affected player(s)
  IF TG_OP = 'DELETE' THEN
    PERFORM recalculate_player_stats(OLD.player_id);
    -- Only check assist_player_id if this is from match_goals table
    IF TG_TABLE_NAME = 'match_goals' AND OLD.assist_player_id IS NOT NULL THEN
      PERFORM recalculate_player_stats(OLD.assist_player_id);
    END IF;
  ELSE
    PERFORM recalculate_player_stats(NEW.player_id);
    -- Only check assist_player_id if this is from match_goals table
    IF TG_TABLE_NAME = 'match_goals' AND NEW.assist_player_id IS NOT NULL THEN
      PERFORM recalculate_player_stats(NEW.assist_player_id);
    END IF;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;
