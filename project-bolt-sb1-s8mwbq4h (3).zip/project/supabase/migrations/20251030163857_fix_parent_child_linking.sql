/*
  # Fix Parent-Child Linking RLS Policy

  ## Problem
  The existing RLS policy prevents parents from linking children because:
  - The WITH CHECK clause requires `parent_id = auth.uid()` on the updated row
  - This creates a circular dependency: parents can only update players they already own
  - Parents cannot take ownership of unlinked players (where parent_id IS NULL)

  ## Solution
  Update the player UPDATE policy to allow:
  1. Managers: Full control over all players (no changes)
  2. Parents: Can update players where:
     - The player is currently unlinked (parent_id IS NULL), OR
     - The player is already linked to them (parent_id = auth.uid())

  This allows parents to:
  - Link unlinked children (set parent_id from NULL to their ID)
  - Update their own linked children
  - Update profile pictures for their children

  This prevents parents from:
  - Stealing other parents' children
  - Changing parent_id from another parent's ID to theirs

  ## Changes
  - Drop existing player update policy
  - Create new policy with corrected WITH CHECK clause
  - Maintain all existing security restrictions
*/

-- Drop the existing policy
DROP POLICY IF EXISTS "Managers and parents can update players" ON players;

-- Create the corrected policy
CREATE POLICY "Managers and parents can update players"
  ON players FOR UPDATE
  TO authenticated
  USING (
    -- Allow if user is a manager
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = (select auth.uid())
      AND role = 'manager'
    )
    OR
    -- Allow if user is a parent and this is their child OR the player is unlinked
    (
      EXISTS (
        SELECT 1 FROM profiles
        WHERE id = (select auth.uid())
        AND role = 'parent'
      )
      AND (
        parent_id = (select auth.uid()) OR parent_id IS NULL
      )
    )
  )
  WITH CHECK (
    -- Managers can do anything
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = (select auth.uid())
      AND role = 'manager'
    )
    OR
    -- Parents can only set parent_id to their own ID or keep it as their ID
    (
      EXISTS (
        SELECT 1 FROM profiles
        WHERE id = (select auth.uid())
        AND role = 'parent'
      )
      AND parent_id = (select auth.uid())
    )
  );
