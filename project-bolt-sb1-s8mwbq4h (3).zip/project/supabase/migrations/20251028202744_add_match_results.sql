/*
  # Add Match Results to Events Table

  ## Overview
  Adds fields to store match results for events, allowing tracking of scores and match outcomes.

  ## Changes
  
  ### Modified Tables
  
  #### `events`
  - `home_score` (integer, optional) - Score for the home team
  - `away_score` (integer, optional) - Score for the away team
  - `result` (text, optional) - Match result: 'win', 'loss', 'draw'
  - `is_home_game` (boolean, default true) - Whether the match is a home game

  ## Notes
  - Only applies to match events, training events won't use these fields
  - Results can be added after the match is completed
  - Scores must be non-negative numbers
*/

-- Add match result fields to events table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'events' AND column_name = 'home_score'
  ) THEN
    ALTER TABLE events ADD COLUMN home_score integer;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'events' AND column_name = 'away_score'
  ) THEN
    ALTER TABLE events ADD COLUMN away_score integer;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'events' AND column_name = 'result'
  ) THEN
    ALTER TABLE events ADD COLUMN result text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'events' AND column_name = 'is_home_game'
  ) THEN
    ALTER TABLE events ADD COLUMN is_home_game boolean DEFAULT true;
  END IF;
END $$;

-- Add check constraints
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'events_home_score_check'
  ) THEN
    ALTER TABLE events ADD CONSTRAINT events_home_score_check 
      CHECK (home_score IS NULL OR home_score >= 0);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'events_away_score_check'
  ) THEN
    ALTER TABLE events ADD CONSTRAINT events_away_score_check 
      CHECK (away_score IS NULL OR away_score >= 0);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'events_result_check'
  ) THEN
    ALTER TABLE events ADD CONSTRAINT events_result_check 
      CHECK (result IS NULL OR result IN ('win', 'loss', 'draw'));
  END IF;
END $$;
