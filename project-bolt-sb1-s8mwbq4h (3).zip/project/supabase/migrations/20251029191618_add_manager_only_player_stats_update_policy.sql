/*
  # Add Manager-Only Update Policy for Player Stats

  1. Changes
    - Drop the existing insecure "System can manage player stats" policy
    - Add separate policies for INSERT and UPDATE operations
    - Managers can insert new player stats records
    - Managers can update existing player stats records
    - Maintains existing SELECT policy for all authenticated users

  2. Security
    - Only users with role='manager' can modify player statistics
    - Parents cannot modify any player statistics
    - All authenticated users can still view statistics
*/

-- Drop the existing overly permissive policy
DROP POLICY IF EXISTS "System can manage player stats" ON player_stats;

-- Allow managers to insert new player stats
CREATE POLICY "Managers can insert player stats"
  ON player_stats FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

-- Allow managers to update player stats
CREATE POLICY "Managers can update player stats"
  ON player_stats FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );
