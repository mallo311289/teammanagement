-- Create Avatars Storage Bucket
--
-- Overview:
-- Creates a public storage bucket for player avatar/profile photos with appropriate security policies.
--
-- Storage Bucket:
-- - Bucket name: avatars
-- - Public: true (allows public read access)
-- - File size limit: 5MB
-- - Allowed MIME types: image/*
--
-- Security Policies:
-- 1. Anyone can view/download files (public access)
-- 2. Authenticated managers can upload/update/delete any avatar
-- 3. Authenticated parents can upload/update avatars in the player-avatars folder for their children
-- 4. File path structure: player-avatars/{player-id}-{timestamp}.{ext}
--
-- Important Notes:
-- - Public bucket allows anyone to view uploaded images
-- - Parents are limited to their own children's avatars
-- - Managers have full control over all avatars

-- Create the avatars bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'avatars',
  'avatars',
  true,
  5242880,
  ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

-- Allow public access to view files
CREATE POLICY "Public can view avatars"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'avatars');

-- Allow authenticated managers to upload any avatar
CREATE POLICY "Managers can upload avatars"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'avatars'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

-- Allow authenticated managers to update any avatar
CREATE POLICY "Managers can update avatars"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'avatars'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

-- Allow authenticated managers to delete any avatar
CREATE POLICY "Managers can delete avatars"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'avatars'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

-- Allow parents to upload avatars for their children
CREATE POLICY "Parents can upload their child's avatar"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = 'player-avatars'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'parent'
    )
  );

-- Allow parents to update avatars for their children
CREATE POLICY "Parents can update their child's avatar"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = 'player-avatars'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'parent'
    )
  );

-- Allow parents to delete avatars for their children
CREATE POLICY "Parents can delete their child's avatar"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = 'player-avatars'
    AND EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'parent'
    )
  );
