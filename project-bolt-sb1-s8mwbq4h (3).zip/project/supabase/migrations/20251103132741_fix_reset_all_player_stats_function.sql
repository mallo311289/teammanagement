/*
  # Fix Reset All Player Stats Function

  ## Summary
  Fixes the `reset_all_player_stats()` function to use correct column names that match the actual `player_stats` table schema.

  ## Changes Made
  
  ### 1. Function Update
    - Corrects column names in UPDATE statement:
      - `goals` → `total_goals`
      - `assists` → `total_assists`
      - Removes non-existent columns: `yellow_cards`, `red_cards`, `minutes_played`
    - Adds `managers_player_count` and `parents_player_count` reset (set to 0)
    - Maintains SECURITY DEFINER and search_path for security
  
  ### 2. Column Names Fixed
    - `total_goals` - Reset to 0
    - `total_assists` - Reset to 0
    - `matches_played` - Reset to 0
    - `managers_player_count` - Reset to 0
    - `parents_player_count` - Reset to 0
  
  ## Security Notes
  - Function uses SECURITY DEFINER to bypass RLS
  - Only managers can execute (controlled by RLS on player_stats table)
  - search_path is set to prevent injection attacks
*/

-- Drop and recreate the function with correct column names
CREATE OR REPLACE FUNCTION reset_all_player_stats()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Reset all player statistics to zero using correct column names
  UPDATE player_stats
  SET 
    total_goals = 0,
    total_assists = 0,
    matches_played = 0,
    managers_player_count = 0,
    parents_player_count = 0,
    updated_at = now();
END;
$$;

-- Ensure the function is executable by authenticated users
GRANT EXECUTE ON FUNCTION reset_all_player_stats() TO authenticated;
