/*
  # Add Parent Link Policy

  1. Changes
    - Add RLS policy to allow parents to update parent_id field on players table
    - Parents can only set parent_id to their own user ID or clear it
    - This enables parents to link/unlink their children
  
  2. Security
    - Parents can only link players to themselves (auth.uid())
    - Parents can only unlink players that are already linked to them
    - Prevents parents from linking other users' children
*/

-- Allow parents to update parent_id field only
CREATE POLICY "Parents can link their children"
  ON players
  FOR UPDATE
  TO authenticated
  USING (
    -- Can update if they're a parent
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'parent'
    )
  )
  WITH CHECK (
    -- Can only set parent_id to themselves or null
    (parent_id = auth.uid() OR parent_id IS NULL)
    AND
    -- Must be a parent
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'parent'
    )
  );
