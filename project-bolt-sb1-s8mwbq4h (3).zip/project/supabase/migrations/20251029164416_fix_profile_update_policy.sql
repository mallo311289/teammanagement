/*
  # Fix Profile Update Policy

  1. Overview
     - Fixes the RLS policy for updating profiles to ensure users can update their own avatar_url
     - Drops and recreates the update policy with correct permissions
  
  2. Changes
     - Drops existing "Users can update own profile" policy
     - Recreates the policy with proper USING and WITH CHECK clauses
  
  3. Security
     - Users can only update their own profile (id must match auth.uid())
     - Ensures avatar_url and other profile fields can be updated by the owner
*/

-- Drop existing policy if it exists
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;

-- Recreate the policy with correct permissions
CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);