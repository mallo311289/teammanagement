/*
  # Add Parent Of to Profiles

  1. Overview
     - Adds a parentOf column to profiles table to store children names
     - Allows parents to register up to 2 children
  
  2. New Column
     - `parentOf` (text array) - Stores up to 2 children names
  
  3. Changes
     - Adds parentOf column with array type
     - Default value is empty array
     - Maximum 2 children per parent
  
  4. Security
     - Uses existing RLS policies
     - Users can update their own profile including parentOf field
*/

-- Add parentOf column to profiles table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'parent_of'
  ) THEN
    ALTER TABLE profiles ADD COLUMN parent_of text[] DEFAULT '{}';
  END IF;
END $$;