/*
  # Add Player-Based Availability System

  ## Overview
  Extends the availability system to track individual player availability for events,
  not just parent attendance. This allows parents to mark each of their children as
  available/unavailable for matches and training sessions.

  ## Changes
  1. Add `player_id` column to availability table
     - Nullable to maintain backward compatibility
     - References players table
     - Indexed for performance

  2. Update RLS policies
     - Allow parents to manage availability for their linked children
     - Maintain existing permissions for parent self-availability

  3. Add check constraint
     - Ensure at least one of user_id or player_id is set
     - Prevent invalid records

  ## Data Model
  - user_id IS NOT NULL, player_id IS NULL: Parent marking their own attendance
  - user_id IS NOT NULL, player_id IS NOT NULL: Parent marking child's availability
  - This allows tracking both parent AND player availability separately

  ## Security
  - Parents can view all availability records (existing)
  - Parents can insert/update availability for themselves (existing)
  - Parents can insert/update availability for their linked children (new)
  - Managers can manage all availability (existing)
*/

-- Add player_id column to availability table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'availability' AND column_name = 'player_id'
  ) THEN
    ALTER TABLE availability ADD COLUMN player_id uuid REFERENCES players(id) ON DELETE CASCADE;
  END IF;
END $$;

-- Add index for performance
CREATE INDEX IF NOT EXISTS availability_player_id_idx ON availability(player_id);

-- Add composite index for event-player lookups
CREATE INDEX IF NOT EXISTS availability_event_player_idx ON availability(event_id, player_id) WHERE player_id IS NOT NULL;

-- Drop existing unique constraint and recreate with player support
ALTER TABLE availability DROP CONSTRAINT IF EXISTS availability_event_id_user_id_key;

-- Add new unique constraint: one availability record per event per user OR per event per player
CREATE UNIQUE INDEX IF NOT EXISTS availability_event_user_unique
  ON availability(event_id, user_id)
  WHERE player_id IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS availability_event_player_unique
  ON availability(event_id, player_id)
  WHERE player_id IS NOT NULL;

-- Update RLS policies for availability table
DROP POLICY IF EXISTS "Users can manage their own availability" ON availability;
DROP POLICY IF EXISTS "Users can insert their own availability" ON availability;
DROP POLICY IF EXISTS "Users can update their own availability" ON availability;
DROP POLICY IF EXISTS "Users can delete their own availability" ON availability;

-- INSERT policy: Users can create availability for themselves OR their children
CREATE POLICY "Users can insert availability"
  ON availability FOR INSERT
  TO authenticated
  WITH CHECK (
    -- User creating their own availability record
    (user_id = (select auth.uid()) AND player_id IS NULL)
    OR
    -- Parent creating availability for their child
    (
      user_id = (select auth.uid())
      AND player_id IS NOT NULL
      AND EXISTS (
        SELECT 1 FROM players
        WHERE players.id = player_id
        AND players.parent_id = (select auth.uid())
      )
    )
    OR
    -- Manager can create any availability
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = (select auth.uid())
      AND role = 'manager'
    )
  );

-- UPDATE policy: Users can update availability for themselves OR their children
CREATE POLICY "Users can update availability"
  ON availability FOR UPDATE
  TO authenticated
  USING (
    -- User updating their own availability
    (user_id = (select auth.uid()) AND player_id IS NULL)
    OR
    -- Parent updating their child's availability
    (
      player_id IS NOT NULL
      AND EXISTS (
        SELECT 1 FROM players
        WHERE players.id = player_id
        AND players.parent_id = (select auth.uid())
      )
    )
    OR
    -- Manager can update any availability
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = (select auth.uid())
      AND role = 'manager'
    )
  )
  WITH CHECK (
    -- User updating their own availability
    (user_id = (select auth.uid()) AND player_id IS NULL)
    OR
    -- Parent updating their child's availability
    (
      user_id = (select auth.uid())
      AND player_id IS NOT NULL
      AND EXISTS (
        SELECT 1 FROM players
        WHERE players.id = player_id
        AND players.parent_id = (select auth.uid())
      )
    )
    OR
    -- Manager can update any availability
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = (select auth.uid())
      AND role = 'manager'
    )
  );

-- DELETE policy: Users can delete availability for themselves OR their children
CREATE POLICY "Users can delete availability"
  ON availability FOR DELETE
  TO authenticated
  USING (
    -- User deleting their own availability
    (user_id = (select auth.uid()) AND player_id IS NULL)
    OR
    -- Parent deleting their child's availability
    (
      player_id IS NOT NULL
      AND EXISTS (
        SELECT 1 FROM players
        WHERE players.id = player_id
        AND players.parent_id = (select auth.uid())
      )
    )
    OR
    -- Manager can delete any availability
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = (select auth.uid())
      AND role = 'manager'
    )
  );
