/*
  # Create Match Lineups Table

  1. New Tables
    - `match_lineups`
      - `id` (uuid, primary key)
      - `event_id` (uuid, foreign key to events)
      - `formation` (text) - e.g., "2-3-1", "1-3-2-1", "3-2-1"
      - `player_positions` (jsonb) - stores player positions on the pitch
      - `created_by` (uuid, foreign key to profiles)
      - `is_home_game` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
  
  2. Security
    - Enable RLS on `match_lineups` table
    - Managers can create, update, and delete lineups
    - All authenticated users can view lineups
  
  3. Important Notes
    - Only one lineup per match
    - player_positions stores array of objects with player_id, position_x, position_y, jersey_number
    - Automatically update updated_at on changes
*/

-- Create match_lineups table
CREATE TABLE IF NOT EXISTS match_lineups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  formation text NOT NULL DEFAULT '2-3-1',
  player_positions jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_by uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  is_home_game boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(event_id)
);

-- Create index
CREATE INDEX IF NOT EXISTS match_lineups_event_idx ON match_lineups(event_id);
CREATE INDEX IF NOT EXISTS match_lineups_created_by_idx ON match_lineups(created_by);

-- Enable RLS
ALTER TABLE match_lineups ENABLE ROW LEVEL SECURITY;

-- RLS Policies for match_lineups

CREATE POLICY "Authenticated users can view lineups"
  ON match_lineups FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Managers can insert lineups"
  ON match_lineups FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

CREATE POLICY "Managers can update lineups"
  ON match_lineups FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

CREATE POLICY "Managers can delete lineups"
  ON match_lineups FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_match_lineups_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for updated_at
CREATE TRIGGER match_lineups_updated_at_trigger
  BEFORE UPDATE ON match_lineups
  FOR EACH ROW
  EXECUTE FUNCTION update_match_lineups_updated_at();
