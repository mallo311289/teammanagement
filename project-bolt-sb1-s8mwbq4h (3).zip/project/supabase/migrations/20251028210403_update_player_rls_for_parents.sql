/*
  # Update Player RLS Policies for Parent Photo Updates

  ## Overview
  Updates the RLS policies on the players table to allow parents to update only the profile photo (avatar_url) of their children.

  ## Security Changes
  
  ### Modified Policies
  - Drop existing "Managers can update players" policy
  - Create new policy "Managers can update all player fields" - allows managers to update any player field
  - Create new policy "Parents can update their child's profile photo" - allows parents to update ONLY the avatar_url field of players where they are listed as parent_id

  ## Implementation
  1. Managers retain full update permissions for all player fields
  2. Parents can update players where parent_id matches their auth.uid()
  3. Frontend will enforce that parents can only modify avatar_url
  4. Additional validation can be added via triggers if needed

  ## Important Notes
  - RLS policies control row-level access
  - Column-level restrictions are enforced at the application level
  - Managers have full update access
  - Parents have update access only to their children's records
*/

-- Drop the existing update policy for managers
DROP POLICY IF EXISTS "Managers can update players" ON players;

-- Create new policy: Managers can update all player fields
CREATE POLICY "Managers can update all player fields"
  ON players FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

-- Create new policy: Parents can update their child's records
-- Note: Application logic will restrict parents to only updating avatar_url
CREATE POLICY "Parents can update their child's profile"
  ON players FOR UPDATE
  TO authenticated
  USING (
    parent_id = auth.uid()
  )
  WITH CHECK (
    parent_id = auth.uid()
  );
