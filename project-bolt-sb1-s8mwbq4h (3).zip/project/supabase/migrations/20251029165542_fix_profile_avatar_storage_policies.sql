/*
  # Fix Profile Avatar Storage Policies

  1. Overview
     - Fixes RLS policies for profile avatar uploads in storage bucket
     - The issue is that policies were too restrictive with filename parsing
     - Simplifies policies to allow authenticated users to manage profile avatars
  
  2. Changes
     - Drops existing restrictive policies
     - Creates new simplified policies that work correctly
     - Allows users to upload/update/delete their own profile avatars
  
  3. Security
     - Users can only manage files in profile-avatars folder
     - Authenticated users required
     - File naming convention: profile-avatars/{user-id}-{timestamp}.{ext}
*/

-- Drop existing profile avatar policies
DROP POLICY IF EXISTS "Users can upload own profile avatar" ON storage.objects;
DROP POLICY IF EXISTS "Users can update own profile avatar" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete own profile avatar" ON storage.objects;

-- Allow authenticated users to upload profile avatars
CREATE POLICY "Users can upload profile avatars"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = 'profile-avatars'
  );

-- Allow authenticated users to update profile avatars
CREATE POLICY "Users can update profile avatars"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = 'profile-avatars'
  );

-- Allow authenticated users to delete profile avatars
CREATE POLICY "Users can delete profile avatars"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = 'profile-avatars'
  );