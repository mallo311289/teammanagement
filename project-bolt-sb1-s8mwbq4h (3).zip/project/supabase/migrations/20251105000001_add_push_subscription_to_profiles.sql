/*
  # Add Push Subscription Support

  1. Schema Changes
    - Add `push_subscription` column to `profiles` table
      - Stores Web Push API subscription data as JSONB
      - Allows null values (users may not enable notifications)

  2. Notes
    - This enables push notifications for match updates, messages, and announcements
    - Subscription data includes endpoint, keys, and expiration info
*/

ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS push_subscription JSONB DEFAULT NULL;

CREATE INDEX IF NOT EXISTS idx_profiles_push_subscription
  ON profiles (id)
  WHERE push_subscription IS NOT NULL;
