/*
  # Add Profile Avatar Storage Policies

  1. Overview
     - Extends the existing avatars bucket to support user profile pictures
     - Allows both managers and parents to upload their own profile avatars
  
  2. Storage Structure
     - Profile avatars path: profile-avatars/{user-id}-{timestamp}.{ext}
     - Uses existing avatars bucket (already configured with 5MB limit)
  
  3. Security Policies
     - Users can upload their own profile picture
     - Users can update their own profile picture
     - Users can delete their own profile picture
     - Public can view all profile pictures
  
  4. Important Notes
     - All users (managers and parents) can manage their own profile picture
     - Profile avatars are stored separately from player avatars
*/

-- Allow authenticated users to upload their own profile avatar
CREATE POLICY "Users can upload own profile avatar"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = 'profile-avatars'
    AND (split_part((storage.filename(name)), '-', 1)) = auth.uid()::text
  );

-- Allow authenticated users to update their own profile avatar
CREATE POLICY "Users can update own profile avatar"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = 'profile-avatars'
    AND (split_part((storage.filename(name)), '-', 1)) = auth.uid()::text
  );

-- Allow authenticated users to delete their own profile avatar
CREATE POLICY "Users can delete own profile avatar"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = 'profile-avatars'
    AND (split_part((storage.filename(name)), '-', 1)) = auth.uid()::text
  );