/*
  # Football Team Management System - Initial Schema
  
  ## Overview
  Creates the core database structure for a football team management application
  with user authentication, role management, events, and availability tracking.
  
  ## New Tables
  
  ### 1. `profiles`
  Extends Supabase auth.users with additional user information
  - `id` (uuid, primary key) - References auth.users
  - `email` (text) - User's email address
  - `full_name` (text) - User's full name
  - `role` (text) - Either 'manager' or 'parent'
  - `team_name` (text) - Name of the team
  - `avatar_url` (text, nullable) - Profile picture URL
  - `created_at` (timestamptz) - Account creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp
  
  ### 2. `events`
  Stores team events (matches and training sessions)
  - `id` (uuid, primary key) - Unique event identifier
  - `created_by` (uuid) - References profiles(id) of creator
  - `title` (text) - Event title
  - `event_type` (text) - 'match' or 'training'
  - `opponent` (text, nullable) - Opponent team name for matches
  - `location` (text) - Event location
  - `event_date` (timestamptz) - Date and time of event
  - `notes` (text, nullable) - Additional event notes
  - `created_at` (timestamptz) - Event creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp
  
  ### 3. `availability`
  Tracks parent availability for events
  - `id` (uuid, primary key) - Unique availability record
  - `event_id` (uuid) - References events(id)
  - `user_id` (uuid) - References profiles(id)
  - `status` (text) - 'available', 'unavailable', or 'maybe'
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp
  - Unique constraint on (event_id, user_id)
  
  ### 4. `chat_messages`
  Stores team chat messages
  - `id` (uuid, primary key) - Unique message identifier
  - `user_id` (uuid) - References profiles(id) of sender
  - `message` (text) - Message content
  - `created_at` (timestamptz) - Message timestamp
  
  ## Security
  
  All tables have Row Level Security (RLS) enabled with the following policies:
  
  ### Profiles
  - Users can view all profiles in their team
  - Users can update their own profile
  - Users can insert their own profile during signup
  
  ### Events
  - All authenticated users can view events
  - Only managers can create, update, and delete events
  
  ### Availability
  - All authenticated users can view availability records
  - Users can manage their own availability
  
  ### Chat Messages
  - All authenticated users can view and create messages
  - Users can delete their own messages
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text NOT NULL,
  role text NOT NULL CHECK (role IN ('manager', 'parent')),
  team_name text NOT NULL DEFAULT 'Moorgreen Colts F.C.',
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create events table
CREATE TABLE IF NOT EXISTS events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_by uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  event_type text NOT NULL CHECK (event_type IN ('match', 'training')),
  opponent text,
  location text NOT NULL,
  event_date timestamptz NOT NULL,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create availability table
CREATE TABLE IF NOT EXISTS availability (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES events(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  status text NOT NULL CHECK (status IN ('available', 'unavailable', 'maybe')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(event_id, user_id)
);

-- Create chat_messages table
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE availability ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Events policies
CREATE POLICY "All users can view events"
  ON events FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Managers can create events"
  ON events FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

CREATE POLICY "Managers can update events"
  ON events FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

CREATE POLICY "Managers can delete events"
  ON events FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

-- Availability policies
CREATE POLICY "All users can view availability"
  ON availability FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own availability"
  ON availability FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own availability"
  ON availability FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own availability"
  ON availability FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Chat messages policies
CREATE POLICY "All users can view messages"
  ON chat_messages FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create messages"
  ON chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own messages"
  ON chat_messages FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_events_date ON events(event_date);
CREATE INDEX IF NOT EXISTS idx_events_created_by ON events(created_by);
CREATE INDEX IF NOT EXISTS idx_availability_event ON availability(event_id);
CREATE INDEX IF NOT EXISTS idx_availability_user ON availability(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_created ON chat_messages(created_at DESC);