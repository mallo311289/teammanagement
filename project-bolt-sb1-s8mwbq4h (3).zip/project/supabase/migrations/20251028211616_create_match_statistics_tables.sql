-- Create Match Statistics Tables
--
-- Overview:
-- Creates tables to track match participation, goalscorers, and player statistics
--
-- New Tables:
-- 1. match_participants - Links players to matches with their participation details
-- 2. match_goals - Tracks goals scored in each match
-- 3. player_stats - Aggregated statistics for each player across all matches
--
-- Security:
-- - All tables have RLS enabled
-- - Managers can manage all data
-- - Parents and authenticated users can view data
--
-- Important Notes:
-- - Statistics are updated via triggers when match data changes
-- - Each player can only be marked as manager's player or parent's player once per match
-- - Goals are linked to both matches and players

-- Create match_participants table
CREATE TABLE IF NOT EXISTS match_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  player_id uuid NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  participated boolean DEFAULT true,
  is_managers_player boolean DEFAULT false,
  is_parents_player boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(event_id, player_id)
);

-- Create match_goals table
CREATE TABLE IF NOT EXISTS match_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  player_id uuid NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  assist_player_id uuid REFERENCES players(id) ON DELETE SET NULL,
  goal_time integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create player_stats table for aggregated statistics
CREATE TABLE IF NOT EXISTS player_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  player_id uuid NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  total_goals integer DEFAULT 0,
  total_assists integer DEFAULT 0,
  matches_played integer DEFAULT 0,
  managers_player_count integer DEFAULT 0,
  parents_player_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(player_id)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS match_participants_event_idx ON match_participants(event_id);
CREATE INDEX IF NOT EXISTS match_participants_player_idx ON match_participants(player_id);
CREATE INDEX IF NOT EXISTS match_goals_event_idx ON match_goals(event_id);
CREATE INDEX IF NOT EXISTS match_goals_player_idx ON match_goals(player_id);
CREATE INDEX IF NOT EXISTS match_goals_assist_idx ON match_goals(assist_player_id);
CREATE INDEX IF NOT EXISTS player_stats_player_idx ON player_stats(player_id);

-- Enable RLS
ALTER TABLE match_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE match_goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE player_stats ENABLE ROW LEVEL SECURITY;

-- RLS Policies for match_participants

CREATE POLICY "Authenticated users can view match participants"
  ON match_participants FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Managers can insert match participants"
  ON match_participants FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

CREATE POLICY "Managers can update match participants"
  ON match_participants FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

CREATE POLICY "Managers can delete match participants"
  ON match_participants FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

-- RLS Policies for match_goals

CREATE POLICY "Authenticated users can view match goals"
  ON match_goals FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Managers can insert match goals"
  ON match_goals FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

CREATE POLICY "Managers can update match goals"
  ON match_goals FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

CREATE POLICY "Managers can delete match goals"
  ON match_goals FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

-- RLS Policies for player_stats

CREATE POLICY "Authenticated users can view player stats"
  ON player_stats FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can manage player stats"
  ON player_stats FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Function to update player statistics
CREATE OR REPLACE FUNCTION update_player_statistics()
RETURNS TRIGGER AS $$
BEGIN
  -- Recalculate stats for the affected player(s)
  IF TG_OP = 'DELETE' THEN
    PERFORM recalculate_player_stats(OLD.player_id);
    IF OLD.assist_player_id IS NOT NULL THEN
      PERFORM recalculate_player_stats(OLD.assist_player_id);
    END IF;
  ELSE
    PERFORM recalculate_player_stats(NEW.player_id);
    IF NEW.assist_player_id IS NOT NULL THEN
      PERFORM recalculate_player_stats(NEW.assist_player_id);
    END IF;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- Function to recalculate stats for a specific player
CREATE OR REPLACE FUNCTION recalculate_player_stats(p_player_id uuid)
RETURNS void AS $$
DECLARE
  v_total_goals integer;
  v_total_assists integer;
  v_matches_played integer;
  v_managers_player integer;
  v_parents_player integer;
BEGIN
  -- Count total goals
  SELECT COUNT(*) INTO v_total_goals
  FROM match_goals
  WHERE player_id = p_player_id;
  
  -- Count total assists
  SELECT COUNT(*) INTO v_total_assists
  FROM match_goals
  WHERE assist_player_id = p_player_id;
  
  -- Count matches played
  SELECT COUNT(*) INTO v_matches_played
  FROM match_participants
  WHERE player_id = p_player_id AND participated = true;
  
  -- Count manager's player awards
  SELECT COUNT(*) INTO v_managers_player
  FROM match_participants
  WHERE player_id = p_player_id AND is_managers_player = true;
  
  -- Count parent's player awards
  SELECT COUNT(*) INTO v_parents_player
  FROM match_participants
  WHERE player_id = p_player_id AND is_parents_player = true;
  
  -- Insert or update player stats
  INSERT INTO player_stats (
    player_id,
    total_goals,
    total_assists,
    matches_played,
    managers_player_count,
    parents_player_count,
    updated_at
  )
  VALUES (
    p_player_id,
    v_total_goals,
    v_total_assists,
    v_matches_played,
    v_managers_player,
    v_parents_player,
    now()
  )
  ON CONFLICT (player_id) DO UPDATE SET
    total_goals = EXCLUDED.total_goals,
    total_assists = EXCLUDED.total_assists,
    matches_played = EXCLUDED.matches_played,
    managers_player_count = EXCLUDED.managers_player_count,
    parents_player_count = EXCLUDED.parents_player_count,
    updated_at = now();
END;
$$ LANGUAGE plpgsql;

-- Triggers to update player statistics when goals are added/modified/deleted
CREATE TRIGGER update_stats_on_goal_change
  AFTER INSERT OR UPDATE OR DELETE ON match_goals
  FOR EACH ROW
  EXECUTE FUNCTION update_player_statistics();

-- Trigger to update player statistics when participation is modified
CREATE TRIGGER update_stats_on_participation_change
  AFTER INSERT OR UPDATE OR DELETE ON match_participants
  FOR EACH ROW
  EXECUTE FUNCTION update_player_statistics();

-- Function to update updated_at timestamp for match_participants
CREATE OR REPLACE FUNCTION update_match_participants_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to update updated_at timestamp for match_goals
CREATE OR REPLACE FUNCTION update_match_goals_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER match_participants_updated_at_trigger
  BEFORE UPDATE ON match_participants
  FOR EACH ROW
  EXECUTE FUNCTION update_match_participants_updated_at();

CREATE TRIGGER match_goals_updated_at_trigger
  BEFORE UPDATE ON match_goals
  FOR EACH ROW
  EXECUTE FUNCTION update_match_goals_updated_at();
