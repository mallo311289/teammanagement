/*
  # Create Announcements Table

  1. New Tables
    - `announcements`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to profiles) - the manager who created it
      - `title` (text) - announcement title
      - `message` (text) - announcement content
      - `priority` (text) - 'normal', 'important', or 'urgent'
      - `created_at` (timestamp)
  
  2. Security
    - Enable RLS on `announcements` table
    - All authenticated users can read announcements
    - Only managers can create announcements
    - Only the creator can delete their announcements
  
  3. Important Notes
    - Announcements display above regular chat messages
    - Priority determines background color styling
*/

CREATE TABLE IF NOT EXISTS announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  message text NOT NULL,
  priority text NOT NULL CHECK (priority IN ('normal', 'important', 'urgent')),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS announcements_created_at_idx ON announcements(created_at DESC);
CREATE INDEX IF NOT EXISTS announcements_user_id_idx ON announcements(user_id);

ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view all announcements"
  ON announcements FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Managers can create announcements"
  ON announcements FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );

CREATE POLICY "Managers can delete own announcements"
  ON announcements FOR DELETE
  TO authenticated
  USING (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );
