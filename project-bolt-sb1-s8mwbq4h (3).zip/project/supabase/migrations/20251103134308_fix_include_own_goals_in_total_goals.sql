/*
  # Include Own Goals in Total Goals Stat

  ## Summary
  Updates the `recalculate_player_stats` function to include own goals in the total goals count.

  ## Changes Made
  
  ### 1. Function Update
    - Removes the filter that excludes own goals from total goals calculation
    - Now counts ALL goals (including own goals) toward a player's total goals stat
    - Maintains all other functionality (assists, matches played, awards)
  
  ### 2. Goal Counting Logic
    - Previous: Only counted goals where `is_own_goal = false OR is_own_goal IS NULL`
    - Updated: Counts all goals for the player, regardless of `is_own_goal` value
  
  ## Security Notes
  - Function maintains SECURITY DEFINER and search_path for security
  - No changes to RLS policies or permissions
*/

-- Update the recalculate_player_stats function to include own goals in total
CREATE OR REPLACE FUNCTION recalculate_player_stats(p_player_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_total_goals integer;
  v_total_assists integer;
  v_matches_played integer;
  v_managers_player integer;
  v_parents_player integer;
BEGIN
  -- Count total goals (INCLUDING own goals)
  SELECT COUNT(*) INTO v_total_goals
  FROM match_goals
  WHERE player_id = p_player_id;
  
  -- Count total assists
  SELECT COUNT(*) INTO v_total_assists
  FROM match_goals
  WHERE assist_player_id = p_player_id;
  
  -- Count matches played
  SELECT COUNT(*) INTO v_matches_played
  FROM match_participants
  WHERE player_id = p_player_id AND participated = true;
  
  -- Count manager's player awards
  SELECT COUNT(*) INTO v_managers_player
  FROM match_participants
  WHERE player_id = p_player_id AND is_managers_player = true;
  
  -- Count parent's player awards
  SELECT COUNT(*) INTO v_parents_player
  FROM match_participants
  WHERE player_id = p_player_id AND is_parents_player = true;
  
  -- Insert or update player stats
  INSERT INTO player_stats (
    player_id,
    total_goals,
    total_assists,
    matches_played,
    managers_player_count,
    parents_player_count,
    updated_at
  )
  VALUES (
    p_player_id,
    v_total_goals,
    v_total_assists,
    v_matches_played,
    v_managers_player,
    v_parents_player,
    now()
  )
  ON CONFLICT (player_id) DO UPDATE SET
    total_goals = EXCLUDED.total_goals,
    total_assists = EXCLUDED.total_assists,
    matches_played = EXCLUDED.matches_played,
    managers_player_count = EXCLUDED.managers_player_count,
    parents_player_count = EXCLUDED.parents_player_count,
    updated_at = now();
END;
$$;
