/*
  # Create Reset Player Statistics Function

  1. Purpose
    - Allows managers to reset all player statistics to zero
    - Clears all stats including goals, assists, matches played, and awards

  2. Security
    - Only managers can execute this function (enforced by RLS)
    - Function resets all player_stats records to zero values

  3. Function
    - reset_all_player_stats(): Resets all statistics for all players
*/

CREATE OR REPLACE FUNCTION reset_all_player_stats()
RETURNS void AS $$
BEGIN
  -- Reset all player statistics to zero
  UPDATE player_stats
  SET 
    total_goals = 0,
    total_assists = 0,
    matches_played = 0,
    managers_player_count = 0,
    parents_player_count = 0,
    updated_at = now();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated users (RLS on player_stats will control actual access)
GRANT EXECUTE ON FUNCTION reset_all_player_stats() TO authenticated;
