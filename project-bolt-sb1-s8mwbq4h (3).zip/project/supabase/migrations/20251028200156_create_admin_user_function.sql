/*
  # Create Admin User Function
  
  ## Overview
  Creates a secure function to add users with properly hashed passwords
  using Supabase's built-in password hashing.
  
  ## New Functions
  
  ### `create_user_with_profile`
  - Creates a user in auth.users with proper password hashing
  - Automatically creates associated profile record
  - Parameters: email, password, full_name, role
  - Returns the created user's ID
  
  ## Security
  - Uses pgcrypto's crypt function for secure password hashing
  - Function runs with security definer to bypass RLS
  - Only accessible by authenticated users
*/

-- Create function to add user with profile
CREATE OR REPLACE FUNCTION create_user_with_profile(
  user_email TEXT,
  user_password TEXT,
  user_full_name TEXT,
  user_role TEXT DEFAULT 'parent'
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_user_id UUID;
BEGIN
  -- Generate new UUID for user
  new_user_id := gen_random_uuid();
  
  -- Insert into auth.users with properly hashed password
  INSERT INTO auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    confirmation_sent_at,
    recovery_sent_at,
    email_change_sent_at,
    raw_app_meta_data,
    raw_user_meta_data,
    is_super_admin,
    created_at,
    updated_at,
    confirmation_token,
    email_change,
    email_change_token_new,
    recovery_token
  ) VALUES (
    '00000000-0000-0000-0000-000000000000',
    new_user_id,
    'authenticated',
    'authenticated',
    user_email,
    crypt(user_password, gen_salt('bf')),
    NOW(),
    NOW(),
    NOW(),
    NOW(),
    jsonb_build_object('provider', 'email', 'providers', ARRAY['email']),
    jsonb_build_object('full_name', user_full_name),
    FALSE,
    NOW(),
    NOW(),
    '',
    '',
    '',
    ''
  );
  
  -- Create profile
  INSERT INTO profiles (
    id,
    email,
    full_name,
    role,
    team_name
  ) VALUES (
    new_user_id,
    user_email,
    user_full_name,
    user_role,
    'Moorgreen Colts F.C.'
  );
  
  RETURN new_user_id;
END;
$$;

-- Create the admin user
SELECT create_user_with_profile(
  'johnnytomlinson@gmail.com',
  'Coach123!',
  'Johnny Tomlinson',
  'manager'
);