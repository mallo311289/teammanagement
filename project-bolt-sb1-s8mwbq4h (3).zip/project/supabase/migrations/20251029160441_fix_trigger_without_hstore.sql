/*
  # Fix Trigger Functions Without Using hstore

  1. Problem
    - Previous fix used hstore extension which is not enabled
    - Error: function hstore(match_goals) does not exist

  2. Solution
    - Create separate trigger functions for match_goals and match_participants
    - Each function only accesses fields that exist in its table
    - No need for dynamic field access or hstore extension

  3. Implementation
    - Create update_player_statistics_for_goals() for match_goals table
    - Create update_player_statistics_for_participants() for match_participants table
    - Update triggers to use the appropriate function
*/

-- Function specifically for match_goals table
CREATE OR REPLACE FUNCTION update_player_statistics_for_goals()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    PERFORM recalculate_player_stats(OLD.player_id);
    IF OLD.assist_player_id IS NOT NULL THEN
      PERFORM recalculate_player_stats(OLD.assist_player_id);
    END IF;
    RETURN OLD;
  ELSE
    PERFORM recalculate_player_stats(NEW.player_id);
    IF NEW.assist_player_id IS NOT NULL THEN
      PERFORM recalculate_player_stats(NEW.assist_player_id);
    END IF;
    RETURN NEW;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Function specifically for match_participants table
CREATE OR REPLACE FUNCTION update_player_statistics_for_participants()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    PERFORM recalculate_player_stats(OLD.player_id);
    RETURN OLD;
  ELSE
    PERFORM recalculate_player_stats(NEW.player_id);
    RETURN NEW;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Drop existing triggers
DROP TRIGGER IF EXISTS update_stats_on_goal_change ON match_goals;
DROP TRIGGER IF EXISTS update_stats_on_participation_change ON match_participants;

-- Create new trigger for match_goals using the goals-specific function
CREATE TRIGGER update_stats_on_goal_change
  AFTER INSERT OR UPDATE OR DELETE ON match_goals
  FOR EACH ROW
  EXECUTE FUNCTION update_player_statistics_for_goals();

-- Create new trigger for match_participants using the participants-specific function
CREATE TRIGGER update_stats_on_participation_change
  AFTER INSERT OR UPDATE OR DELETE ON match_participants
  FOR EACH ROW
  EXECUTE FUNCTION update_player_statistics_for_participants();
