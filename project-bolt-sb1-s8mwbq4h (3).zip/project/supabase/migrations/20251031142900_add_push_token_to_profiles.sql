/*
  # Add Push Token Support for Mobile Notifications

  1. Changes
    - Add `push_token` column to `profiles` table to store device FCM/APNS tokens
    - This enables sending push notifications to mobile devices
  
  2. Security
    - Column is nullable as not all users will have push notifications enabled
    - Users can update their own push token through the existing profile update policy
*/

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'push_token'
  ) THEN
    ALTER TABLE profiles ADD COLUMN push_token text;
  END IF;
END $$;