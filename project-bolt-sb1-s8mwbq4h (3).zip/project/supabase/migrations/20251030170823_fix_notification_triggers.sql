/*
  # Fix Notification Trigger Functions

  ## Problem
  The notification trigger functions were using incorrect column name `related_id`
  instead of `reference_id` when inserting into the notifications table.
  This causes chat messages to fail with error:
  "column 'related_id' of relation 'notifications' does not exist"

  ## Solution
  Update all three notification functions to use the correct column name `reference_id`:
  - notify_new_message() - for chat messages
  - notify_new_announcement() - for announcements
  - notify_new_event() - for events

  ## Changes
  - Replace `related_id` with `reference_id` in INSERT statements
  - Maintain all other functionality unchanged
*/

-- Function: notify_new_message
CREATE OR REPLACE FUNCTION notify_new_message()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  sender_name text;
BEGIN
  SELECT full_name INTO sender_name FROM profiles WHERE id = NEW.user_id;

  INSERT INTO notifications (user_id, type, title, message, reference_id)
  SELECT
    id,
    'message',
    'New message from ' || sender_name,
    LEFT(NEW.message, 100),
    NEW.id
  FROM profiles
  WHERE id != NEW.user_id;

  RETURN NEW;
END;
$$;

-- Function: notify_new_announcement
CREATE OR REPLACE FUNCTION notify_new_announcement()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO notifications (user_id, type, title, message, reference_id)
  SELECT
    id,
    'announcement',
    'New Announcement',
    NEW.message,
    NEW.id
  FROM profiles
  WHERE id != NEW.user_id;

  RETURN NEW;
END;
$$;

-- Function: notify_new_event
CREATE OR REPLACE FUNCTION notify_new_event()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO notifications (user_id, type, title, message, reference_id)
  SELECT
    id,
    'event',
    'New Event',
    NEW.title || ' on ' || TO_CHAR(NEW.event_date, 'Mon DD at HH24:MI'),
    NEW.id
  FROM profiles
  WHERE id != NEW.created_by;

  RETURN NEW;
END;
$$;
