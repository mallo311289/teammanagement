/*
  # Add Manager Chat Message Deletion Policy

  ## Overview
  Allows managers to delete any chat message, not just their own messages.
  This gives managers moderation capabilities for the team chat.

  ## Changes
  1. Add new RLS policy for managers to delete any chat message
  2. Existing policy allows users to delete their own messages (unchanged)

  ## Security
  - Managers can delete any chat message (for moderation)
  - Regular users can still only delete their own messages
  - Policy checks user role from profiles table
*/

-- Add policy for managers to delete any chat message
CREATE POLICY "Managers can delete any message"
  ON chat_messages FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'manager'
    )
  );
