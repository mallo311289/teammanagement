/*
  # Create Notification Triggers

  1. Functions
    - `notify_new_message()` - Creates notifications for all users except sender when new message posted
    - `notify_new_announcement()` - Creates notifications for all users except poster when announcement created
    - `notify_new_event()` - Creates notifications for all users except creator when event created
  
  2. Triggers
    - Trigger on chat_messages INSERT
    - Trigger on announcements INSERT
    - Trigger on events INSERT
  
  3. Important Notes
    - Notifications only sent to users other than the creator
    - Automatic notification creation on new content
*/

CREATE OR REPLACE FUNCTION notify_new_message()
RETURNS TRIGGER AS $$
DECLARE
  sender_name text;
BEGIN
  SELECT full_name INTO sender_name FROM profiles WHERE id = NEW.user_id;
  
  INSERT INTO notifications (user_id, type, reference_id, title, message)
  SELECT 
    id,
    'message',
    NEW.id,
    'New message from ' || sender_name,
    LEFT(NEW.message, 100)
  FROM profiles
  WHERE id != NEW.user_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION notify_new_announcement()
RETURNS TRIGGER AS $$
DECLARE
  poster_name text;
BEGIN
  SELECT full_name INTO poster_name FROM profiles WHERE id = NEW.user_id;
  
  INSERT INTO notifications (user_id, type, reference_id, title, message)
  SELECT 
    id,
    'announcement',
    NEW.id,
    'New announcement: ' || NEW.title,
    LEFT(NEW.message, 100)
  FROM profiles
  WHERE id != NEW.user_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION notify_new_event()
RETURNS TRIGGER AS $$
DECLARE
  creator_name text;
  event_title text;
BEGIN
  SELECT full_name INTO creator_name FROM profiles WHERE id = NEW.created_by;
  
  event_title := NEW.title || ' - ' || TO_CHAR(NEW.event_date::timestamp, 'Mon DD, HH24:MI');
  
  INSERT INTO notifications (user_id, type, reference_id, title, message)
  SELECT 
    id,
    'event',
    NEW.id,
    'New event: ' || NEW.title,
    event_title
  FROM profiles
  WHERE id != NEW.created_by;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_notify_new_message ON chat_messages;
CREATE TRIGGER trigger_notify_new_message
  AFTER INSERT ON chat_messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_message();

DROP TRIGGER IF EXISTS trigger_notify_new_announcement ON announcements;
CREATE TRIGGER trigger_notify_new_announcement
  AFTER INSERT ON announcements
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_announcement();

DROP TRIGGER IF EXISTS trigger_notify_new_event ON events;
CREATE TRIGGER trigger_notify_new_event
  AFTER INSERT ON events
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_event();
