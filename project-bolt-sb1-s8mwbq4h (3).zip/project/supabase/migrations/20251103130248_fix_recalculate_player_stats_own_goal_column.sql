/*
  # Fix recalculate_player_stats Function to Use Correct Column Name

  1. Changes
    - Update `recalculate_player_stats` function to use `is_own_goal` instead of `own_goal`
    - Ensure own goals are properly excluded from player goal statistics
    - Fix the function logic to correctly calculate goals and assists

  2. Notes
    - This fixes the "column mg.own_goal does not exist" error
    - Own goals should not count toward a player's goal statistics
*/

-- Drop and recreate the recalculate_player_stats function with correct column name
CREATE OR REPLACE FUNCTION recalculate_player_stats(p_player_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_total_goals integer;
  v_total_assists integer;
  v_matches_played integer;
  v_managers_player integer;
  v_parents_player integer;
BEGIN
  -- Count total goals (excluding own goals)
  SELECT COUNT(*) INTO v_total_goals
  FROM match_goals
  WHERE player_id = p_player_id 
    AND (is_own_goal = false OR is_own_goal IS NULL);
  
  -- Count total assists
  SELECT COUNT(*) INTO v_total_assists
  FROM match_goals
  WHERE assist_player_id = p_player_id;
  
  -- Count matches played
  SELECT COUNT(*) INTO v_matches_played
  FROM match_participants
  WHERE player_id = p_player_id AND participated = true;
  
  -- Count manager's player awards
  SELECT COUNT(*) INTO v_managers_player
  FROM match_participants
  WHERE player_id = p_player_id AND is_managers_player = true;
  
  -- Count parent's player awards
  SELECT COUNT(*) INTO v_parents_player
  FROM match_participants
  WHERE player_id = p_player_id AND is_parents_player = true;
  
  -- Insert or update player stats
  INSERT INTO player_stats (
    player_id,
    total_goals,
    total_assists,
    matches_played,
    managers_player_count,
    parents_player_count,
    updated_at
  )
  VALUES (
    p_player_id,
    v_total_goals,
    v_total_assists,
    v_matches_played,
    v_managers_player,
    v_parents_player,
    now()
  )
  ON CONFLICT (player_id) DO UPDATE SET
    total_goals = EXCLUDED.total_goals,
    total_assists = EXCLUDED.total_assists,
    matches_played = EXCLUDED.matches_played,
    managers_player_count = EXCLUDED.managers_player_count,
    parents_player_count = EXCLUDED.parents_player_count,
    updated_at = now();
END;
$$;
