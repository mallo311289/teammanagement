import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface PushNotificationPayload {
  tokens: string[];
  title: string;
  body: string;
  data?: Record<string, any>;
}

interface ServiceAccount {
  type: string;
  project_id: string;
  private_key_id: string;
  private_key: string;
  client_email: string;
  client_id: string;
  auth_uri: string;
  token_uri: string;
  auth_provider_x509_cert_url: string;
  client_x509_cert_url: string;
  universe_domain: string;
}

const serviceAccount: ServiceAccount = {
  type: "service_account",
  project_id: "teamtrack-moorgreen",
  private_key_id: "f052134df70b76dc46987a7231023ac8ddfa7e41",
  private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDz+Sl0Uecs/Cxb\nD77qwogsn2qK8gjr6IXuUlq01ap2LRI+32CtGBVCC9gwhHDv6gxskAj6vyPXxwWT\nlwhgMRF7F8Pk5Tvyzq1neC7IMV5pL5ccfluXofVZRmO8c4i7WiKezOzXkpJ895nN\nXaOTKi5nugc17dU5nr2s+QbrI57BCei/xeUIIUS5vYBuXbf6oQruvYk+DxsvoIo+\nyEO/QZ27kEleXlgEUWcYKdV3Xfcv3DfsbdupTHc2r4Ybhqhe3hXG8Wzn2cona45i\nBndCEXeE6r7X3abA0d9LU0YzXx/qT45EQ5PXzRUgJ+rLgllBXjb/2IaHmoCtNLtg\n5Y1ceyaPAgMBAAECggEAA0Q9fEd0pUPhYUxFGft52doltlQpeGryuyqsiv8ytNhb\n1V8BJPxZtIOtg0t0MJtLAj6g+tD3S6cGws1c1g+Kgjvu5CQDfyKFkRVsPZiFJYPe\ngxYO+bJWoQ7BHg7HSPwIlfc/xwlp4lB1a4eYbl3CQ33w3DQJbmTItpggsgPZRLtT\nQV1jO8DM5xt/T1JAqbkX2hI1EreR3zO21tYbtYCLhWOyHXI0dp0PdPKs/gAD5QF+\n8Vf1qyqqISWX8ASR7dkxY7ssY0Fm5cwRFRrlfCujY+fz6fgLnbI03g7TCM+fUTTt\nzHHuCdUYJP2Likh2fTdLkfvI9GjFaVLH+S0BLYp4SQKBgQD5/kfKzN1sC0R6g0EX\nmR2P+o6bv+0yAVuZtbjHoUfkYEmr4zEokOL7xmkqszba39g0b5NFkfYrQ3mWOs46\n/JUJtyem7r78n9ei7kBuZP9cTEYAUbxId/iqnD+GLmXamqwQKT7fzbXUzEth4I+y\na3Xxp+PSQgjAus6KRdrQmeGmKwKBgQD51dos2Si7KKOinG0qtA0ye8W0Tgd0QdqJ\nn+pUX2tNvEC3Z7d/0TwNPF/zL5w+F+aFRy/s4ifynqS/fe84tLdwLjASbJ0yQ0Od\nFtZ98fwhmxyigutLTJwNeJxQ1OwB7Q3TT65p8ySi+39a1JRtv0F38VMNp/CbCMeX\nDHJ7VVNTLQKBgHQqAUguO/F5pt9a4ENL5d3CasPawihLUzowo+U3f0WSrIkPsAcO\nlDq0Lqgl0KaR/1AWTJO2SHJAD16MgsoMFmEGV4mNRPf0emn+Vbg2fCZyVtDNKjVu\ncgEtS6NZKgETgEKeN9YdK5HvQFQB2iPpJUweXJGWF6Ue6Nx9qzjlWGIzAoGBAI+t\n1w1Xzj7kfkb0Yyvd5IEWAXtSLKNFhCMF3sOrJJDOJQHVGgjeEgUipaO7y8VCBYa8\ni+lVnte/OMwP5tXbyGsxhN/zquvPF0Fucuh3lCLXi75CQINLiauNo4gxC5GH/R17\ng7jW5kj9Dh70hnAfP8108ei2nn7qq65IsEYRqhv5AoGBANlhjRFL6SZ3ioX4fNYx\nyVkJBcpz75rKohGh8kDw2bKvEE3yIrBm5JstKDCuDjL8x/je9sHLoMj1YigA4fX0\nAk4Qm3t8/eabHyHJ1o4hjdCP2Y4UP/DFO61c/0rEvRE5iDi3krvo0TKIkUesPrI3\n8VShD6wZB+fUhuUEhsEj6ayk\n-----END PRIVATE KEY-----\n",
  client_email: "firebase-adminsdk-fbsvc@teamtrack-moorgreen.iam.gserviceaccount.com",
  client_id: "112418404370308418613",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40teamtrack-moorgreen.iam.gserviceaccount.com",
  universe_domain: "googleapis.com"
};

async function getAccessToken(): Promise<string> {
  const header = {
    alg: "RS256",
    typ: "JWT",
  };

  const now = Math.floor(Date.now() / 1000);
  const claim = {
    iss: serviceAccount.client_email,
    scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: serviceAccount.token_uri,
    exp: now + 3600,
    iat: now,
  };

  const encodedHeader = btoa(JSON.stringify(header)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  const encodedClaim = btoa(JSON.stringify(claim)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  const signatureInput = `${encodedHeader}.${encodedClaim}`;

  const privateKey = serviceAccount.private_key;
  const pemHeader = "-----BEGIN PRIVATE KEY-----";
  const pemFooter = "-----END PRIVATE KEY-----";
  const pemContents = privateKey.substring(
    pemHeader.length,
    privateKey.length - pemFooter.length
  ).replace(/\s/g, "");

  const binaryKey = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));

  const cryptoKey = await crypto.subtle.importKey(
    "pkcs8",
    binaryKey,
    {
      name: "RSASSA-PKCS1-v1_5",
      hash: "SHA-256",
    },
    false,
    ["sign"]
  );

  const signature = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    cryptoKey,
    new TextEncoder().encode(signatureInput)
  );

  const encodedSignature = btoa(String.fromCharCode(...new Uint8Array(signature)))
    .replace(/=/g, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");

  const jwt = `${signatureInput}.${encodedSignature}`;

  const tokenResponse = await fetch(serviceAccount.token_uri, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });

  if (!tokenResponse.ok) {
    throw new Error(`Failed to get access token: ${tokenResponse.statusText}`);
  }

  const tokenData = await tokenResponse.json();
  return tokenData.access_token;
}

async function sendPushNotification(
  token: string,
  title: string,
  body: string,
  data?: Record<string, any>
): Promise<void> {
  const accessToken = await getAccessToken();

  const message = {
    message: {
      token,
      notification: {
        title,
        body,
      },
      data: data || {},
      android: {
        priority: "high",
      },
      apns: {
        headers: {
          "apns-priority": "10",
        },
        payload: {
          aps: {
            sound: "default",
          },
        },
      },
    },
  };

  const fcmEndpoint = `https://fcm.googleapis.com/v1/projects/${serviceAccount.project_id}/messages:send`;

  const response = await fetch(fcmEndpoint, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(message),
  });

  if (!response.ok) {
    const errorData = await response.text();
    throw new Error(`FCM API error: ${response.status} - ${errorData}`);
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { tokens, title, body, data }: PushNotificationPayload = await req.json();

    if (!tokens || tokens.length === 0) {
      return new Response(
        JSON.stringify({ error: "No push tokens provided" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const results = await Promise.allSettled(
      tokens.map((token) => sendPushNotification(token, title, body, data))
    );

    const successful = results.filter((r) => r.status === "fulfilled").length;
    const failed = results.filter((r) => r.status === "rejected").length;

    if (failed > 0) {
      console.error("Some notifications failed:",
        results
          .filter((r) => r.status === "rejected")
          .map((r) => (r as PromiseRejectedResult).reason)
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        sent: successful,
        failed,
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error sending push notifications:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});