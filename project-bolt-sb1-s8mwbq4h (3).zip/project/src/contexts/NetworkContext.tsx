import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type NetworkContextType = {
  isOnline: boolean;
  connectionType: string;
};

const NetworkContext = createContext<NetworkContextType | undefined>(undefined);

export function NetworkProvider({ children }: { children: ReactNode }) {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [connectionType, setConnectionType] = useState('unknown');

  useEffect(() => {
    const updateConnectionType = () => {
      if ('connection' in navigator) {
        const conn = (navigator as any).connection;
        setConnectionType(conn?.effectiveType || 'unknown');
      }
    };

    const handleOnline = () => {
      setIsOnline(true);
      updateConnectionType();
    };

    const handleOffline = () => {
      setIsOnline(false);
      setConnectionType('none');
    };

    updateConnectionType();

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    if ('connection' in navigator) {
      (navigator as any).connection?.addEventListener('change', updateConnectionType);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if ('connection' in navigator) {
        (navigator as any).connection?.removeEventListener('change', updateConnectionType);
      }
    };
  }, []);

  return (
    <NetworkContext.Provider value={{ isOnline, connectionType }}>
      {children}
    </NetworkContext.Provider>
  );
}

export function useNetwork() {
  const context = useContext(NetworkContext);
  if (context === undefined) {
    throw new Error('useNetwork must be used within a NetworkProvider');
  }
  return context;
}
