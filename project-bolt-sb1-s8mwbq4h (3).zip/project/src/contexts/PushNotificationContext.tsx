import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';

type PushNotificationContextType = {
  requestPermission: () => Promise<boolean>;
  isSupported: boolean;
  permission: NotificationPermission;
};

const PushNotificationContext = createContext<PushNotificationContextType | undefined>(undefined);

const urlBase64ToUint8Array = (base64String: string) => {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
};

export function PushNotificationProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [isSupported, setIsSupported] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission>('default');

  useEffect(() => {
    const supported = 'Notification' in window && 'serviceWorker' in navigator && 'PushManager' in window;
    setIsSupported(supported);

    if (supported) {
      setPermission(Notification.permission);
    }
  }, []);

  useEffect(() => {
    if (isSupported && Notification.permission === 'granted' && user) {
      subscribeToPushNotifications();
    }
  }, [isSupported, user]);

  const subscribeToPushNotifications = async () => {
    try {
      const registration = await navigator.serviceWorker.ready;

      const existingSubscription = await registration.pushManager.getSubscription();
      if (existingSubscription) {
        await savePushSubscription(existingSubscription);
        return;
      }

      const vapidPublicKey = 'BEl62iUYgUivxIkv-LoN9P6Fn0Nt_tJFdq8vDzgKaAuWO7d0KzB3FqWfK9eDG0jfQaT9H5qzJnK2QWJ8vZ-_U4M';
      const convertedVapidKey = urlBase64ToUint8Array(vapidPublicKey);

      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: convertedVapidKey,
      });

      await savePushSubscription(subscription);
    } catch (error) {
      if (import.meta.env.DEV) {
        // eslint-disable-next-line no-console
        console.error('Failed to subscribe to push notifications:', error);
      }
    }
  };

  const savePushSubscription = async (subscription: PushSubscription) => {
    if (!user) return;

    const subscriptionJSON = subscription.toJSON();

    await supabase
      .from('profiles')
      .update({
        push_subscription: subscriptionJSON,
      })
      .eq('id', user.id);
  };

  const requestPermission = async (): Promise<boolean> => {
    if (!isSupported) {
      return false;
    }

    if (Notification.permission === 'granted') {
      await subscribeToPushNotifications();
      return true;
    }

    if (Notification.permission === 'denied') {
      return false;
    }

    const result = await Notification.requestPermission();
    setPermission(result);

    if (result === 'granted') {
      await subscribeToPushNotifications();
      return true;
    }

    return false;
  };

  return (
    <PushNotificationContext.Provider value={{ requestPermission, isSupported, permission }}>
      {children}
    </PushNotificationContext.Provider>
  );
}

export function usePushNotifications() {
  const context = useContext(PushNotificationContext);
  if (context === undefined) {
    throw new Error('usePushNotifications must be used within a PushNotificationProvider');
  }
  return context;
}
