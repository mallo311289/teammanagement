import { useState } from 'react';
import { X } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useToast } from '../../hooks/use-toast';

type NewAnnouncementModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

export function NewAnnouncementModal({ isOpen, onClose }: NewAnnouncementModalProps) {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [priority, setPriority] = useState<'normal' | 'important' | 'urgent'>('normal');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim() || !message.trim() || !profile) return;

    try {
      setLoading(true);
      const { error } = await supabase.from('announcements').insert({
        user_id: profile.id,
        title: title.trim(),
        message: message.trim(),
        priority,
      });

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Announcement posted successfully',
      });

      setTitle('');
      setMessage('');
      setPriority('normal');
      onClose();
    } catch (error: any) {
      // console.error('Error creating announcement:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to create announcement',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (!loading) {
      setTitle('');
      setMessage('');
      setPriority('normal');
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl">
        <div className="flex items-center justify-between p-6 border-b border-slate-200">
          <h2 className="text-xl font-bold text-slate-900">New Announcement</h2>
          <button
            onClick={handleClose}
            disabled={loading}
            className="w-8 h-8 rounded-full hover:bg-red-100 flex items-center justify-center transition-colors disabled:opacity-50"
          >
            <X className="w-5 h-5 text-red-600 hover:text-red-700" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Title
            </label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter announcement title"
              disabled={loading}
              required
              maxLength={100}
              className="w-full"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Message
            </label>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Enter announcement details..."
              disabled={loading}
              required
              maxLength={1000}
              rows={5}
              className="w-full resize-none"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Priority
            </label>
            <Select
              value={priority}
              onValueChange={(value: 'normal' | 'important' | 'urgent') => setPriority(value)}
              disabled={loading}
            >
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="normal">Normal</SelectItem>
                <SelectItem value="important">Important</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={loading}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={!title.trim() || !message.trim() || loading}
              className="flex-1 bg-[#4A6FA5] hover:bg-[#3d5c8f]"
            >
              {loading ? 'Posting...' : 'Post Announcement'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
