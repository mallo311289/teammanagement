import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Player, supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useToast } from '../../hooks/use-toast';
import { Loader2, User } from 'lucide-react';

const playerSchema = z.object({
  full_name: z.string().min(2, 'Name must be at least 2 characters'),
  jersey_number: z.string().optional(),
  position: z.enum(['Goalkeeper', 'Defender', 'Midfielder', 'Forward', 'none']).optional(),
  date_of_birth: z.string().optional(),
  email: z.string().email('Invalid email').or(z.literal('')).optional(),
  phone: z.string().optional(),
  avatar_url: z.string().optional(),
});

type PlayerFormData = z.infer<typeof playerSchema>;

type EditPlayerModalProps = {
  player: Player | null;
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
};

export function EditPlayerModal({ player, open, onClose, onSuccess }: EditPlayerModalProps) {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const isManager = profile?.role === 'manager';
  const isParent = profile?.role === 'parent' && player?.parent_id === profile?.id;
  const canEditPhoto = isManager || isParent;
  const canEditBasicInfo = isManager || isParent;
  const canEditAllFields = isManager;

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<PlayerFormData>({
    resolver: zodResolver(playerSchema),
  });

  const avatarUrl = watch('avatar_url');

  useEffect(() => {
    if (player && open) {
      reset({
        full_name: player.full_name,
        jersey_number: player.jersey_number?.toString() || '',
        position: player.position || 'none',
        date_of_birth: player.date_of_birth || '',
        email: player.email || '',
        phone: player.phone || '',
        avatar_url: player.avatar_url || '',
      });
      setPreviewUrl(player.avatar_url || null);
    }
  }, [player, open, reset]);

  useEffect(() => {
    if (avatarUrl) {
      setPreviewUrl(avatarUrl);
    }
  }, [avatarUrl]);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !player) return;

    try {
      setUploading(true);

      const fileExt = file.name.split('.').pop();
      const fileName = `${player.id}-${Date.now()}.${fileExt}`;
      const filePath = `player-avatars/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      setValue('avatar_url', urlData.publicUrl);
      setPreviewUrl(urlData.publicUrl);

      toast({
        title: 'Success',
        description: 'Photo uploaded successfully',
      });
    } catch (error) {
      // console.error('Error uploading file:', error);
      toast({
        title: 'Error',
        description: 'Failed to upload photo',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
    }
  };

  const onSubmit = async (data: PlayerFormData) => {
    if (!player) return;

    try {
      setLoading(true);

      const updateData: Partial<Player> = {};

      if (isManager) {
        updateData.full_name = data.full_name;
        updateData.jersey_number = data.jersey_number ? parseInt(data.jersey_number) : undefined;
        updateData.position = (data.position && data.position !== 'none') ? data.position : undefined;
        updateData.date_of_birth = data.date_of_birth || undefined;
        updateData.email = data.email || undefined;
        updateData.phone = data.phone || undefined;
        updateData.avatar_url = data.avatar_url || undefined;
      } else if (isParent) {
        updateData.avatar_url = data.avatar_url || undefined;
        updateData.date_of_birth = data.date_of_birth || undefined;
        updateData.phone = data.phone || undefined;
      }

      const { error } = await supabase
        .from('players')
        .update(updateData)
        .eq('id', player.id);

      if (error) throw error;

      toast({
        title: 'Success',
        description: isManager ? 'Player updated successfully' : 'Profile updated successfully',
      });

      onSuccess();
      onClose();
    } catch (error) {
      // console.error('Error updating player:', error);
      toast({
        title: 'Error',
        description: 'Failed to update player',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (!player) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {isManager ? 'Edit Player' : 'Update Child Profile'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Profile Photo Section */}
          {canEditPhoto && (
            <div className="space-y-4">
              <Label>Profile Photo</Label>
              <div className="flex items-center gap-6">
                <div className="relative w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold text-3xl shadow-lg overflow-hidden">
                  {previewUrl ? (
                    <img src={previewUrl} alt={player.full_name} className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-12 h-12" />
                  )}
                </div>
                <div className="flex-1">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    disabled={uploading}
                    className="mb-2"
                  />
                  <p className="text-sm text-slate-500">
                    Upload a profile photo (JPG, PNG, max 5MB)
                  </p>
                  {uploading && (
                    <div className="flex items-center gap-2 mt-2 text-blue-600">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span className="text-sm">Uploading...</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Basic info fields - Parents and Managers */}
          {canEditBasicInfo && !isManager && (
            <>
              <div className="space-y-2">
                <Label htmlFor="date_of_birth">Date of Birth</Label>
                <Input
                  id="date_of_birth"
                  type="date"
                  {...register('date_of_birth')}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  {...register('phone')}
                  placeholder="e.g., 07123456789"
                />
              </div>
            </>
          )}

          {/* Manager-only fields */}
          {canEditAllFields && (
            <>
              <div className="space-y-2">
                <Label htmlFor="full_name">Full Name *</Label>
                <Input
                  id="full_name"
                  {...register('full_name')}
                  placeholder="Enter player name"
                />
                {errors.full_name && (
                  <p className="text-sm text-red-600">{errors.full_name.message}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="jersey_number">Jersey Number</Label>
                  <Input
                    id="jersey_number"
                    type="number"
                    {...register('jersey_number')}
                    placeholder="e.g., 10"
                    min="1"
                    max="99"
                  />
                  {errors.jersey_number && (
                    <p className="text-sm text-red-600">{errors.jersey_number.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="position">Position</Label>
                  <Select
                    value={watch('position') || 'none'}
                    onValueChange={(value) => setValue('position', value as any)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select position" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="Goalkeeper">Goalkeeper</SelectItem>
                      <SelectItem value="Defender">Defender</SelectItem>
                      <SelectItem value="Midfielder">Midfielder</SelectItem>
                      <SelectItem value="Forward">Forward</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="date_of_birth">Date of Birth</Label>
                <Input
                  id="date_of_birth"
                  type="date"
                  {...register('date_of_birth')}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  {...register('email')}
                  placeholder="player@example.com"
                />
                {errors.email && (
                  <p className="text-sm text-red-600">{errors.email.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  {...register('phone')}
                  placeholder="e.g., 07123456789"
                />
              </div>
            </>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading || uploading}>
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Changes'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
