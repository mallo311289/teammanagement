import { User, Mail, Phone, Calendar, Shield, Target, Award, TrendingUp, Edit } from 'lucide-react';
import { Player } from '../../lib/supabase';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';

type PlayerCardProps = {
  player: Player;
  onEdit?: () => void;
  canEdit?: boolean;
};

export function PlayerCard({ player, onEdit, canEdit }: PlayerCardProps) {
  const getPositionIcon = () => {
    switch (player.position) {
      case 'Goalkeeper':
        return <Shield className="w-5 h-5" />;
      case 'Defender':
        return <Award className="w-5 h-5" />;
      case 'Midfielder':
        return <Target className="w-5 h-5" />;
      case 'Forward':
        return <TrendingUp className="w-5 h-5" />;
      default:
        return <User className="w-5 h-5" />;
    }
  };

  const getPositionColor = () => {
    switch (player.position) {
      case 'Goalkeeper':
        return 'bg-yellow-500/20 text-yellow-700 dark:text-yellow-400 border-yellow-500/30';
      case 'Defender':
        return 'bg-blue-500/20 text-blue-700 dark:text-blue-400 border-blue-500/30';
      case 'Midfielder':
        return 'bg-green-500/20 text-green-700 dark:text-green-400 border-green-500/30';
      case 'Forward':
        return 'bg-red-500/20 text-red-700 dark:text-red-400 border-red-500/30';
      default:
        return 'bg-slate-500/20 text-slate-700 dark:text-slate-400 border-slate-500/30';
    }
  };

  const calculateAge = (dob: string) => {
    const today = new Date();
    const birthDate = new Date(dob);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  return (
    <div className="group relative bg-white/95 backdrop-blur-sm rounded-2xl p-6 border border-white/20 shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all duration-300 min-h-[140px]">
      {canEdit && onEdit && (
        <Button
          onClick={(e) => {
            e.stopPropagation();
            onEdit();
          }}
          variant="ghost"
          size="icon"
          className="absolute top-4 right-4 h-8 w-8 rounded-full bg-slate-100 hover:bg-slate-200 transition-colors z-10"
        >
          <Edit className="w-4 h-4" />
        </Button>
      )}

      <div className="flex items-start gap-4">
        <div className="relative">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold text-2xl shadow-lg overflow-hidden">
            {player.avatar_url ? (
              <img src={player.avatar_url} alt={player.full_name} className="w-full h-full object-cover" />
            ) : player.jersey_number ? (
              player.jersey_number
            ) : (
              <User className="w-8 h-8" />
            )}
          </div>
          {player.position && (
            <div className={`absolute -bottom-1 -right-1 p-1.5 rounded-full ${getPositionColor()} border-2 border-white dark:border-slate-900 shadow-md`}>
              {getPositionIcon()}
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <h3 className="text-xl font-bold text-slate-900 mb-1 truncate">
            {player.full_name}
          </h3>

          {player.position && (
            <Badge variant="secondary" className={`mb-3 ${getPositionColor()} border`}>
              {player.position}
            </Badge>
          )}

          <div className="space-y-2">
            {player.date_of_birth && (
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Calendar className="w-4 h-4 flex-shrink-0" />
                <span>Age {calculateAge(player.date_of_birth)}</span>
              </div>
            )}

            {player.email && (
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Mail className="w-4 h-4 flex-shrink-0" />
                <span className="truncate">{player.email}</span>
              </div>
            )}

            {player.phone && (
              <div className="flex items-center gap-2 text-sm text-slate-600">
                <Phone className="w-4 h-4 flex-shrink-0" />
                <span>{player.phone}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
