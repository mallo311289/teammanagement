import { useState, useEffect, useRef } from 'react';
import { cn } from '../../lib/utils';

type LazyImageProps = {
  src: string;
  alt: string;
  className?: string;
  placeholderClassName?: string;
  onLoad?: () => void;
  onError?: () => void;
};

export function LazyImage({
  src,
  alt,
  className,
  placeholderClassName,
  onLoad,
  onError,
}: LazyImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isInView, setIsInView] = useState(false);
  const [hasError, setHasError] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    if (!imgRef.current) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          observer.disconnect();
        }
      },
      {
        rootMargin: '50px',
      }
    );

    observer.observe(imgRef.current);

    return () => {
      observer.disconnect();
    };
  }, []);

  const handleLoad = () => {
    setIsLoaded(true);
    onLoad?.();
  };

  const handleError = () => {
    setHasError(true);
    onError?.();
  };

  if (hasError) {
    return (
      <div
        className={cn(
          'flex items-center justify-center bg-slate-200',
          placeholderClassName || className
        )}
      >
        <span className="text-slate-400 text-sm">Failed to load image</span>
      </div>
    );
  }

  return (
    <>
      {!isLoaded && (
        <div
          className={cn(
            'animate-pulse bg-slate-200',
            placeholderClassName || className
          )}
        />
      )}
      <img
        ref={imgRef}
        src={isInView ? src : undefined}
        alt={alt}
        className={cn(
          className,
          isLoaded ? 'opacity-100' : 'opacity-0',
          'transition-opacity duration-300'
        )}
        onLoad={handleLoad}
        onError={handleError}
        loading="lazy"
      />
    </>
  );
}
