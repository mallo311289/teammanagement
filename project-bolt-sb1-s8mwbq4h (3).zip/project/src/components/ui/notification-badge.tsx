type NotificationBadgeProps = {
  count: number;
  className?: string;
};

export function NotificationBadge({ count, className = '' }: NotificationBadgeProps) {
  if (count === 0) return null;

  return (
    <div
      className={`absolute -top-1 -right-1 min-w-[18px] h-[18px] bg-gradient-to-br from-red-500 to-red-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1 shadow-lg border-2 border-white animate-in zoom-in-50 duration-200 ring-2 ring-red-400/50 ${className}`}
    >
      {count > 99 ? '99+' : count}
    </div>
  );
}
