export function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#4A6FA5] via-[#5B7DB8] to-[#6B8BC3]">
      <div className="text-center space-y-4">
        <div className="animate-spin rounded-full h-16 w-16 border-4 border-white border-t-transparent mx-auto"></div>
        <p className="text-white text-lg">Loading...</p>
      </div>
    </div>
  );
}
