import { useState, useEffect } from 'react';
import { Edit3 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Player, PlayerStats } from '../../lib/supabase';

type EditPlayerStatsModalProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  player: Player;
  stats: PlayerStats | null;
  onSave: (playerId: string, stats: {
    total_goals: number;
    total_assists: number;
    matches_played: number;
    managers_player_count: number;
    parents_player_count: number;
  }) => Promise<void>;
};

export function EditPlayerStatsModal({
  open,
  onOpenChange,
  player,
  stats,
  onSave,
}: EditPlayerStatsModalProps) {
  const [totalGoals, setTotalGoals] = useState(0);
  const [totalAssists, setTotalAssists] = useState(0);
  const [matchesPlayed, setMatchesPlayed] = useState(0);
  const [managersPlayerCount, setManagersPlayerCount] = useState(0);
  const [parentsPlayerCount, setParentsPlayerCount] = useState(0);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (stats) {
      setTotalGoals(stats.total_goals);
      setTotalAssists(stats.total_assists);
      setMatchesPlayed(stats.matches_played);
      setManagersPlayerCount(stats.managers_player_count);
      setParentsPlayerCount(stats.parents_player_count);
    } else {
      setTotalGoals(0);
      setTotalAssists(0);
      setMatchesPlayed(0);
      setManagersPlayerCount(0);
      setParentsPlayerCount(0);
    }
  }, [stats, open]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await onSave(player.id, {
        total_goals: totalGoals,
        total_assists: totalAssists,
        matches_played: matchesPlayed,
        managers_player_count: managersPlayerCount,
        parents_player_count: parentsPlayerCount,
      });
      onOpenChange(false);
    } catch (error) {
      // console.error('Error saving stats:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleNumberChange = (
    value: string,
    setter: (val: number) => void
  ) => {
    const num = parseInt(value) || 0;
    setter(Math.max(0, num));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Edit3 className="w-5 h-5 text-blue-600" />
            Edit Player Statistics
          </DialogTitle>
          <DialogDescription>
            Manually update statistics for this player
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-3 p-4 bg-slate-50 dark:bg-slate-900 rounded-lg mb-4">
          <Avatar className="w-12 h-12">
            {player.avatar_url ? (
              <AvatarImage src={player.avatar_url} alt={player.full_name} />
            ) : (
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-blue-600 text-white font-bold">
                {player.jersey_number || player.full_name.charAt(0)}
              </AvatarFallback>
            )}
          </Avatar>
          <div>
            <h3 className="font-semibold text-slate-900 dark:text-white">
              {player.full_name}
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              {player.position || 'Player'}
              {player.jersey_number && ` • #${player.jersey_number}`}
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="goals">Total Goals</Label>
              <Input
                id="goals"
                type="number"
                min="0"
                value={totalGoals}
                onChange={(e) => handleNumberChange(e.target.value, setTotalGoals)}
                className="text-base"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="assists">Total Assists</Label>
              <Input
                id="assists"
                type="number"
                min="0"
                value={totalAssists}
                onChange={(e) => handleNumberChange(e.target.value, setTotalAssists)}
                className="text-base"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="matches">Matches Played</Label>
            <Input
              id="matches"
              type="number"
              min="0"
              value={matchesPlayed}
              onChange={(e) => handleNumberChange(e.target.value, setMatchesPlayed)}
              className="text-base"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="managers-player">Manager's Player</Label>
              <Input
                id="managers-player"
                type="number"
                min="0"
                value={managersPlayerCount}
                onChange={(e) => handleNumberChange(e.target.value, setManagersPlayerCount)}
                className="text-base"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="parents-player">Parent's Player</Label>
              <Input
                id="parents-player"
                type="number"
                min="0"
                value={parentsPlayerCount}
                onChange={(e) => handleNumberChange(e.target.value, setParentsPlayerCount)}
                className="text-base"
              />
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={saving}
          >
            Cancel
          </Button>
          <Button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
