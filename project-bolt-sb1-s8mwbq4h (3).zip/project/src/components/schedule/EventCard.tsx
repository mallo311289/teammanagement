import { Calendar, MapPin, Users, Trophy, Dumbbell, Briefcase, Edit, Trash2, Pencil } from 'lucide-react';
import { format } from 'date-fns';
import { Event } from '../../lib/supabase';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';

type EventCardProps = {
  event: Event & { availableCount?: number; totalCount?: number };
  onClick?: () => void;
  onEditScore?: () => void;
  canEditScore?: boolean;
  onEdit?: () => void;
  onDelete?: () => void;
  canManage?: boolean;
};

export function EventCard({ event, onClick, onEditScore, canEditScore, onEdit, onDelete, canManage }: EventCardProps) {
  const isPast = new Date(event.event_date) < new Date();

  const getEventIcon = () => {
    switch (event.event_type) {
      case 'match':
        return <Trophy className="w-5 h-5" />;
      case 'training':
        return <Dumbbell className="w-5 h-5" />;
      default:
        return <Briefcase className="w-5 h-5" />;
    }
  };

  const getEventColor = () => {
    switch (event.event_type) {
      case 'match':
        return 'bg-gradient-to-br from-red-500 to-red-600 border-red-400/30';
      case 'training':
        return 'bg-gradient-to-br from-blue-500 to-blue-600 border-blue-400/30';
      default:
        return 'bg-gradient-to-br from-green-500 to-green-600 border-green-400/30';
    }
  };

  return (
    <div className={`group relative bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm rounded-2xl p-3 sm:p-5 border border-slate-200/50 dark:border-slate-700/50 shadow-lg hover:shadow-xl transition-all duration-300 ${
        isPast ? 'opacity-60' : ''
      }`}
    >
      <div className={`absolute top-0 left-0 w-1.5 sm:w-2 h-full rounded-l-2xl ${getEventColor().split(' ')[0]}`} />

      {canManage && (onEdit || onDelete) && (
        <div className="absolute top-2 right-2 sm:top-4 sm:right-4 flex flex-col sm:flex-row gap-1 sm:gap-2 z-10">
          {onEdit && (
            <Button
              onClick={(e) => {
                e.stopPropagation();
                onEdit();
              }}
              variant="ghost"
              size="sm"
              className="h-7 w-7 sm:h-8 sm:w-auto p-0 sm:px-3 sm:gap-2 bg-blue-100 dark:bg-blue-900/30 hover:bg-blue-200 dark:hover:bg-blue-800/40 text-blue-700 dark:text-blue-400"
            >
              <Pencil className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Edit</span>
            </Button>
          )}
          {onDelete && (
            <Button
              onClick={(e) => {
                e.stopPropagation();
                onDelete();
              }}
              variant="ghost"
              size="sm"
              className="h-7 w-7 sm:h-8 sm:w-auto p-0 sm:px-3 sm:gap-2 bg-red-100 dark:bg-red-900/30 hover:bg-red-200 dark:hover:bg-red-800/40 text-red-700 dark:text-red-400"
            >
              <Trash2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Delete</span>
            </Button>
          )}
        </div>
      )}

      {canEditScore && onEditScore && event.event_type === 'match' && (
        <Button
          onClick={(e) => {
            e.stopPropagation();
            onEditScore();
          }}
          variant="ghost"
          size="sm"
          className="absolute bottom-2 right-2 sm:top-16 sm:bottom-auto sm:right-4 h-7 sm:h-8 px-2 sm:px-3 gap-1 sm:gap-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 z-10 text-xs sm:text-sm"
        >
          <Edit className="w-3 h-3 sm:w-4 sm:h-4" />
          <span className="hidden xs:inline">{event.result ? 'Edit Score' : 'Add Score'}</span>
          <span className="xs:hidden">Score</span>
        </Button>
      )}

      <div
        onClick={onClick}
        className="flex items-start justify-between gap-2 sm:gap-4 ml-2 sm:ml-3 cursor-pointer"
      >
        <div className="flex-1 min-w-0 pr-8 sm:pr-0">
          <div className="flex items-start gap-2 sm:gap-3 mb-2 sm:mb-3">
            <div className={`p-2 sm:p-2.5 rounded-lg sm:rounded-xl ${getEventColor()} text-white shadow-md flex-shrink-0`}>
              {getEventIcon()}
            </div>

            <div className="flex-1 min-w-0">
              <h3 className="text-sm sm:text-lg font-bold text-slate-900 dark:text-white mb-0.5 sm:mb-1 line-clamp-2 leading-tight sm:leading-normal">
                {event.title}
              </h3>
              {event.opponent && (
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 truncate">
                  vs {event.opponent}
                </p>
              )}
              {event.event_type === 'match' && event.result && event.home_score !== null && event.away_score !== null && (
                <div className="mt-1.5 sm:mt-2 flex flex-col xs:flex-row items-start xs:items-center gap-1.5 sm:gap-2">
                  <div className="inline-flex items-center gap-1.5 sm:gap-2 bg-slate-100 dark:bg-slate-800 px-2 sm:px-3 py-1 sm:py-1.5 rounded-md sm:rounded-lg">
                    <span className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                      {event.is_home_game ? event.home_score : event.away_score}
                    </span>
                    <span className="text-xs text-slate-500 dark:text-slate-400">-</span>
                    <span className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                      {event.is_home_game ? event.away_score : event.home_score}
                    </span>
                  </div>
                  <Badge
                    variant={event.result === 'win' ? 'default' : event.result === 'loss' ? 'destructive' : 'secondary'}
                    className={`text-[10px] sm:text-xs font-semibold px-2 sm:px-2.5 py-0.5 sm:py-1 ${
                      event.result === 'win'
                        ? 'bg-green-600 hover:bg-green-700'
                        : event.result === 'loss'
                        ? 'bg-red-600 hover:bg-red-700'
                        : 'bg-slate-500 hover:bg-slate-600'
                    }`}
                  >
                    {event.result.toUpperCase()}
                  </Badge>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-1.5 sm:space-y-2 mb-3 sm:mb-4">
            <div className="flex items-start sm:items-center gap-2 text-slate-600 dark:text-slate-400 text-xs sm:text-sm">
              <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4 flex-shrink-0 mt-0.5 sm:mt-0" />
              <span className="font-medium leading-tight">
                {format(new Date(event.event_date), 'EEEE, d MMMM yyyy • HH:mm')}
              </span>
            </div>

            <div className="flex items-start sm:items-center gap-2 text-slate-600 dark:text-slate-400 text-xs sm:text-sm">
              <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4 flex-shrink-0 mt-0.5 sm:mt-0" />
              <span className="line-clamp-1 leading-tight">{event.location}</span>
            </div>
          </div>

          {event.notes && (
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 line-clamp-2 mb-2 sm:mb-3">
              {event.notes}
            </p>
          )}
        </div>

        <div className="flex flex-col items-end gap-2 flex-shrink-0">
          {event.availableCount !== undefined && event.totalCount !== undefined && (
            <Badge
              variant="secondary"
              className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold shadow-sm text-xs sm:text-sm px-1.5 sm:px-2.5 py-0.5 sm:py-1"
            >
              <Users className="w-3 h-3 sm:w-3.5 sm:h-3.5 mr-1 sm:mr-1.5" />
              {event.availableCount}/{event.totalCount}
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}
