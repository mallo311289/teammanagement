import { useState, useRef, useEffect } from 'react';
import { Users } from 'lucide-react';
import { Player } from '../../lib/supabase';

type PlayerPosition = {
  player_id: string;
  player_name: string;
  jersey_number: number | null;
  position: string | null;
  x: number;
  y: number;
  is_substitute?: boolean;
};

type PitchFormationProps = {
  selectedPlayers: string[];
  allPlayers: Player[];
  positions: PlayerPosition[];
  onPositionsChange: (positions: PlayerPosition[]) => void;
  editable?: boolean;
};

const DEFAULT_FORMATION = {
  '2-3-1': [
    { x: 50, y: 85 },
    { x: 30, y: 70 },
    { x: 70, y: 70 },
    { x: 20, y: 45 },
    { x: 50, y: 45 },
    { x: 80, y: 45 },
    { x: 50, y: 20 },
  ],
};

export function PitchFormation({
  selectedPlayers,
  allPlayers,
  positions,
  onPositionsChange,
  editable = true,
}: PitchFormationProps) {
  const pitchRef = useRef<HTMLDivElement>(null);
  const [draggingPlayer, setDraggingPlayer] = useState<string | null>(null);


  useEffect(() => {
    if (selectedPlayers.length > 0 && positions.length === 0) {
      initializePositions();
    }
  }, [selectedPlayers]);

  const initializePositions = () => {
    const defaultPositions = DEFAULT_FORMATION['2-3-1'];
    const newPositions: PlayerPosition[] = selectedPlayers.slice(0, 7).map((playerId, index) => {
      const player = allPlayers.find((p) => p.id === playerId);
      const pos = defaultPositions[index] || { x: 50, y: 50 };
      return {
        player_id: playerId,
        player_name: player?.full_name || 'Unknown',
        jersey_number: player?.jersey_number || null,
        position: player?.position || null,
        x: pos.x,
        y: pos.y,
        is_substitute: false,
      };
    });

    selectedPlayers.slice(7).forEach((playerId) => {
      const player = allPlayers.find((p) => p.id === playerId);
      newPositions.push({
        player_id: playerId,
        player_name: player?.full_name || 'Unknown',
        jersey_number: player?.jersey_number || null,
        position: player?.position || null,
        x: 0,
        y: 0,
        is_substitute: true,
      });
    });

    onPositionsChange(newPositions);
  };

  const handleMouseDown = (e: React.MouseEvent, playerId: string) => {
    if (!editable) return;
    e.preventDefault();
    e.stopPropagation();
    setDraggingPlayer(playerId);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!draggingPlayer || !pitchRef.current || !editable) return;
    e.preventDefault();

    const rect = pitchRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    const clampedX = Math.max(5, Math.min(95, x));
    const clampedY = Math.max(5, Math.min(95, y));

    const updatedPositions = positions.map((pos) =>
      pos.player_id === draggingPlayer ? { ...pos, x: clampedX, y: clampedY } : pos
    );

    onPositionsChange(updatedPositions);
  };

  const handleMouseUp = () => {
    setDraggingPlayer(null);
  };

  const handleTouchStart = (e: React.TouchEvent, playerId: string) => {
    if (!editable) return;
    e.preventDefault();
    e.stopPropagation();
    setDraggingPlayer(playerId);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!draggingPlayer || !pitchRef.current || !editable) return;
    e.preventDefault();

    const touch = e.touches[0];
    const rect = pitchRef.current.getBoundingClientRect();
    const x = ((touch.clientX - rect.left) / rect.width) * 100;
    const y = ((touch.clientY - rect.top) / rect.height) * 100;

    const clampedX = Math.max(5, Math.min(95, x));
    const clampedY = Math.max(5, Math.min(95, y));

    const updatedPositions = positions.map((pos) =>
      pos.player_id === draggingPlayer ? { ...pos, x: clampedX, y: clampedY } : pos
    );

    onPositionsChange(updatedPositions);
  };

  const handleTouchEnd = () => {
    setDraggingPlayer(null);
  };

  const starters = positions.filter((p) => !p.is_substitute);

  return (
    <div className="space-y-4">
      <div
        ref={pitchRef}
        className="relative w-full bg-gradient-to-b from-green-500 to-green-600 rounded-2xl shadow-2xl overflow-hidden"
        style={{
          aspectRatio: '2/3',
          maxHeight: '600px',
        }}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/3 h-16 border-2 border-white rounded-b-xl"></div>
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/6 h-8 border-2 border-white rounded-b-lg"></div>

          <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-white"></div>
          <div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 border-2 border-white rounded-full"
            style={{ aspectRatio: '1' }}
          ></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full"></div>

          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1/3 h-16 border-2 border-white rounded-t-xl"></div>
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1/6 h-8 border-2 border-white rounded-t-lg"></div>
        </div>

        <div className="absolute inset-0">
          {starters.map((playerPos) => (
            <div
              key={playerPos.player_id}
              className={`absolute -translate-x-1/2 -translate-y-1/2 transition-transform ${
                editable ? 'cursor-move hover:scale-110' : ''
              } ${draggingPlayer === playerPos.player_id ? 'scale-110 z-50' : 'z-10'}`}
              style={{
                left: `${playerPos.x}%`,
                top: `${playerPos.y}%`,
              }}
              onMouseDown={(e) => handleMouseDown(e, playerPos.player_id)}
              onTouchStart={(e) => handleTouchStart(e, playerPos.player_id)}
            >
              <div className="flex flex-col items-center gap-1">
                <div className="w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center border-2 border-green-700 text-green-700 font-bold text-lg">
                  {playerPos.jersey_number || <Users className="w-6 h-6" />}
                </div>
                <div className="bg-white/90 px-2 py-0.5 rounded-full text-xs font-semibold text-slate-900 whitespace-nowrap shadow-md">
                  {playerPos.player_name.split(' ').pop()}
                </div>
              </div>
            </div>
          ))}
        </div>

        {editable && (
          <div className="absolute top-2 left-2 bg-white/90 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 shadow-md">
            {starters.length} / 7 on pitch
          </div>
        )}
      </div>

      {editable && (
        <p className="text-sm text-slate-600 text-center">
          Drag players to position them on the pitch
        </p>
      )}
    </div>
  );
}
