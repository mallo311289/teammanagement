import { useState, useEffect } from 'react';
import { Users, Check, Loader2, Clipboard } from 'lucide-react';
import { supabase, Player, Event } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../ui/tabs';
import { PitchFormation } from './PitchFormation';
import { useToast } from '../../hooks/use-toast';
import { format } from 'date-fns';

type PlayerPosition = {
  player_id: string;
  player_name: string;
  jersey_number: number | null;
  position: string | null;
  x: number;
  y: number;
  is_substitute?: boolean;
};

type LineupPickerModalProps = {
  event: Event | null;
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
};

export function LineupPickerModal({ event, open, onClose, onSuccess }: LineupPickerModalProps) {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [players, setPlayers] = useState<Player[]>([]);
  const [selectedPlayers, setSelectedPlayers] = useState<string[]>([]);
  const [playerPositions, setPlayerPositions] = useState<PlayerPosition[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingPlayers, setLoadingPlayers] = useState(true);
  const [activeTab, setActiveTab] = useState<'select' | 'formation'>('select');

  useEffect(() => {
    if (open && event) {
      loadPlayers();
    }
  }, [open, event]);

  useEffect(() => {
    if (open && event && players.length > 0) {
      loadExistingLineup();
    }
  }, [open, event, players]);

  const loadPlayers = async () => {
    try {
      setLoadingPlayers(true);
      const { data, error } = await supabase
        .from('players')
        .select('*')
        .order('jersey_number', { ascending: true, nullsFirst: false });

      if (error) throw error;
      setPlayers(data || []);
    } catch (error) {
      // console.error('Error loading players:', error);
      toast({
        title: 'Error',
        description: 'Failed to load players',
        variant: 'destructive',
      });
    } finally {
      setLoadingPlayers(false);
    }
  };

  const loadExistingLineup = async () => {
    if (!event) return;

    try {
      const { data, error } = await supabase
        .from('match_lineups')
        .select('player_positions')
        .eq('event_id', event.id)
        .maybeSingle();

      if (error) throw error;

      if (data && data.player_positions) {
        const positions = data.player_positions as PlayerPosition[];
        const playerIds = positions.map((p) => p.player_id);
        setSelectedPlayers(playerIds);

        const enrichedPositions = positions.map((pos) => {
          const player = players.find((p) => p.id === pos.player_id);
          return {
            ...pos,
            player_name: pos.player_name || player?.full_name || 'Unknown',
            jersey_number: pos.jersey_number ?? player?.jersey_number ?? null,
            position: pos.position || player?.position || null,
          };
        });

        setPlayerPositions(enrichedPositions);
      }
    } catch (error) {
      // console.error('Error loading existing lineup:', error);
    }
  };

  const togglePlayer = (playerId: string) => {
    setSelectedPlayers((prev) => {
      if (prev.includes(playerId)) {
        return prev.filter((id) => id !== playerId);
      } else {
        return [...prev, playerId];
      }
    });
  };

  const notifyAllMembers = async () => {
    if (!event) return;

    try {
      const { data: allProfiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id');

      if (profilesError) throw profilesError;

      const notifications = allProfiles.map((profile) => ({
        user_id: profile.id,
        type: 'event' as const,
        reference_id: event.id,
        title: 'Starting Lineup Announced',
        message: `The starting lineup for ${event.title} has been submitted. Check the lineup to see if you're playing!`,
        is_read: false,
      }));

      const { error: notifError } = await supabase
        .from('notifications')
        .insert(notifications);

      if (notifError) throw notifError;
    } catch (error) {
      // console.error('Error creating notifications:', error);
    }
  };

  const handleSubmit = async () => {
    if (!event || !profile || selectedPlayers.length === 0) {
      toast({
        title: 'Invalid Selection',
        description: 'Please select at least one player for the lineup',
        variant: 'destructive',
      });
      return;
    }

    try {
      setLoading(true);

      const finalPositions = selectedPlayers.map((playerId, index) => {
        const player = players.find((p) => p.id === playerId);
        const existingPosition = playerPositions.find((p) => p.player_id === playerId);

        return {
          player_id: playerId,
          player_name: player?.full_name || 'Unknown',
          jersey_number: player?.jersey_number || null,
          position: player?.position || null,
          x: existingPosition?.x ?? 50,
          y: existingPosition?.y ?? 50,
          is_substitute: index >= 7,
        };
      });

      const { data: existingLineup } = await supabase
        .from('match_lineups')
        .select('id')
        .eq('event_id', event.id)
        .maybeSingle();

      if (existingLineup) {
        const { error: updateError } = await supabase
          .from('match_lineups')
          .update({
            player_positions: finalPositions,
            is_home_game: event.is_home_game ?? true,
          })
          .eq('id', existingLineup.id);

        if (updateError) throw updateError;
      } else {
        const { error: insertError } = await supabase
          .from('match_lineups')
          .insert({
            event_id: event.id,
            formation: '2-3-1',
            player_positions: finalPositions,
            created_by: profile.id,
            is_home_game: event.is_home_game ?? true,
          });

        if (insertError) throw insertError;
      }

      await notifyAllMembers();

      toast({
        title: 'Success',
        description: 'Starting lineup has been submitted and all members have been notified',
      });

      onSuccess();
      onClose();
    } catch (error) {
      // console.error('Error submitting lineup:', error);
      toast({
        title: 'Error',
        description: 'Failed to submit lineup',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (!event) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Select Starting Lineup
          </DialogTitle>
          <p className="text-sm text-slate-600 mt-2">
            {event.title} - {format(new Date(event.event_date), 'EEE, d MMM')}
          </p>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'select' | 'formation')}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="select" className="gap-2">
              <Users className="w-4 h-4" />
              Select Players
            </TabsTrigger>
            <TabsTrigger value="formation" className="gap-2" disabled={selectedPlayers.filter((_, i) => i < 7).length === 0}>
              <Clipboard className="w-4 h-4" />
              Formation
            </TabsTrigger>
          </TabsList>

          <TabsContent value="select" className="space-y-4 mt-4">
          <div className="grid grid-cols-3 gap-2">
            <div className="flex flex-col items-center p-3 bg-green-50 border border-green-200 rounded-lg">
              <span className="text-xs font-medium text-green-700 mb-1">Starters</span>
              <Badge className="bg-green-600 text-white text-lg px-3 py-1">
                {Math.min(selectedPlayers.length, 7)}
              </Badge>
            </div>
            <div className="flex flex-col items-center p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <span className="text-xs font-medium text-orange-700 mb-1">Substitutes</span>
              <Badge className="bg-orange-600 text-white text-lg px-3 py-1">
                {Math.max(0, selectedPlayers.length - 7)}
              </Badge>
            </div>
            <div className="flex flex-col items-center p-3 bg-slate-50 border border-slate-200 rounded-lg">
              <span className="text-xs font-medium text-slate-700 mb-1">Total</span>
              <Badge variant="secondary" className="text-lg px-3 py-1">
                {selectedPlayers.length}
              </Badge>
            </div>
          </div>

          {loadingPlayers ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
            </div>
          ) : players.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-600">No players available</p>
            </div>
          ) : (
            <div className="space-y-2">
              {players.map((player) => {
                const isSelected = selectedPlayers.includes(player.id);
                const selectionIndex = selectedPlayers.indexOf(player.id);
                const isStarter = isSelected && selectionIndex < 7;
                const isSubstitute = isSelected && selectionIndex >= 7;

                return (
                  <button
                    key={player.id}
                    onClick={() => togglePlayer(player.id)}
                    className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all ${
                      isStarter
                        ? 'border-green-500 bg-green-50'
                        : isSubstitute
                        ? 'border-orange-500 bg-orange-50'
                        : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div
                        className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg ${
                          isStarter
                            ? 'bg-green-600'
                            : isSubstitute
                            ? 'bg-orange-600'
                            : 'bg-gradient-to-br from-blue-500 to-blue-600'
                        }`}
                      >
                        {player.avatar_url ? (
                          <img
                            src={player.avatar_url}
                            alt={player.full_name}
                            className="w-full h-full object-cover rounded-full"
                          />
                        ) : player.jersey_number ? (
                          player.jersey_number
                        ) : (
                          <Users className="w-6 h-6" />
                        )}
                      </div>

                      <div className="text-left">
                        <h3 className="font-semibold text-slate-900">
                          {player.full_name}
                        </h3>
                        {player.position && (
                          <p className="text-sm text-slate-600">{player.position}</p>
                        )}
                      </div>
                    </div>

                    {isSelected && (
                      <div className="flex items-center gap-2">
                        <Badge className={isStarter ? 'bg-green-600' : 'bg-orange-600'}>
                          {isStarter ? 'Starter' : 'Sub'}
                        </Badge>
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                          isStarter ? 'bg-green-600' : 'bg-orange-600'
                        }`}>
                          <Check className="w-4 h-4 text-white" />
                        </div>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          )}
          </TabsContent>

          <TabsContent value="formation" className="space-y-4 mt-4">
            <PitchFormation
              selectedPlayers={selectedPlayers}
              allPlayers={players}
              positions={playerPositions}
              onPositionsChange={setPlayerPositions}
              editable={true}
            />
          </TabsContent>
        </Tabs>

        <div className="flex gap-3 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            className="flex-1"
            disabled={loading}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            className="flex-1 bg-blue-600 hover:bg-blue-700"
            disabled={loading || selectedPlayers.length === 0}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Submitting...
              </>
            ) : (
              'Submit Lineup'
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
