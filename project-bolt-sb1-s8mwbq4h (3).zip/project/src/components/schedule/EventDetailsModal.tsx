import { useEffect, useState } from 'react';
import { Calendar, MapPin, Trophy, Dumbbell, Check, X, Clock, HelpCircle, Users, Clipboard } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../ui/tabs';
import { Event, AvailabilityWithProfile, AvailabilityWithPlayer, Player, supabase } from '../../lib/supabase';
import { PitchFormation } from './PitchFormation';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../hooks/use-toast';
import { format } from 'date-fns';

type EventDetailsModalProps = {
  event: Event | null;
  open: boolean;
  onClose: () => void;
  onUpdate?: () => void;
};

type AvailabilityStatus = 'available' | 'unavailable' | 'maybe' | 'no_response';

type LineupPlayer = {
  player_id: string;
  player_name: string;
  jersey_number: number | null;
  position: string | null;
  x: number;
  y: number;
  is_substitute?: boolean;
};

export function EventDetailsModal({ event, open, onClose, onUpdate }: EventDetailsModalProps) {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [availabilities, setAvailabilities] = useState<AvailabilityWithProfile[]>([]);
  const [playerAvailabilities, setPlayerAvailabilities] = useState<AvailabilityWithPlayer[]>([]);
  const [allPlayers, setAllPlayers] = useState<Player[]>([]);
  const [linkedPlayers, setLinkedPlayers] = useState<Player[]>([]);
  const [userStatus, setUserStatus] = useState<AvailabilityStatus>('no_response');
  const [loading, setLoading] = useState(false);
  const [lineup, setLineup] = useState<LineupPlayer[]>([]);
  const [lineupTab, setLineupTab] = useState<'list' | 'formation'>('list');

  useEffect(() => {
    if (event && open) {
      loadAvailabilities();
      loadPlayers();
      if (profile?.role === 'parent' || profile?.role === 'manager') {
        loadLinkedPlayers();
      }
      if (event.event_type === 'match') {
        loadLineup();
      }
    }
  }, [event, open, profile]);

  const loadAvailabilities = async () => {
    if (!event) return;

    try {
      const { data: parentData, error: parentError } = await supabase
        .from('availability')
        .select('*, profile:profiles(*)')
        .eq('event_id', event.id)
        .is('player_id', null);

      if (parentError) throw parentError;

      const { data: playerData, error: playerError } = await supabase
        .from('availability')
        .select('*, player:players(*)')
        .eq('event_id', event.id)
        .not('player_id', 'is', null);

      if (playerError) throw playerError;

      setAvailabilities((parentData as any) || []);
      setPlayerAvailabilities((playerData as any) || []);

      if (profile) {
        const userAvail = parentData?.find((a) => a.user_id === profile.id);
        setUserStatus(userAvail?.status || 'no_response');
      }
    } catch (error) {
      // console.error('Error loading availabilities:', error);
    }
  };

  const loadPlayers = async () => {
    try {
      const { data, error } = await supabase
        .from('players')
        .select('*')
        .order('full_name', { ascending: true });

      if (error) throw error;
      setAllPlayers(data || []);
    } catch (error) {
      // console.error('Error loading players:', error);
    }
  };

  const loadLinkedPlayers = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('players')
        .select('*')
        .eq('parent_id', profile.id);

      if (error) throw error;
      setLinkedPlayers(data || []);
    } catch (error) {
      // console.error('Error loading linked players:', error);
    }
  };

  const loadLineup = async () => {
    if (!event) return;

    try {
      const { data, error } = await supabase
        .from('match_lineups')
        .select('player_positions')
        .eq('event_id', event.id)
        .maybeSingle();

      if (error) throw error;

      if (data && data.player_positions) {
        setLineup(data.player_positions as LineupPlayer[]);
      } else {
        setLineup([]);
      }
    } catch (error) {
      // console.error('Error loading lineup:', error);
      setLineup([]);
    }
  };

  const updateAvailability = async (status: Exclude<AvailabilityStatus, 'no_response'>) => {
    if (!event || !profile) return;

    setLoading(true);
    try {
      const existing = availabilities.find((a) => a.user_id === profile.id);

      if (existing) {
        await supabase
          .from('availability')
          .update({ status })
          .eq('id', existing.id);
      } else {
        await supabase
          .from('availability')
          .insert({ event_id: event.id, user_id: profile.id, status, player_id: null });
      }

      setUserStatus(status);
      await loadAvailabilities();
      onUpdate?.();

      toast({
        title: 'Status Updated',
        description: `Your availability has been set to ${status}`,
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update availability',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const updatePlayerAvailability = async (playerId: string, status: Exclude<AvailabilityStatus, 'no_response'>) => {
    if (!event || !profile) return;

    setLoading(true);
    try {
      const existing = playerAvailabilities.find((a) => a.player_id === playerId);

      if (existing) {
        await supabase
          .from('availability')
          .update({ status })
          .eq('id', existing.id);
      } else {
        await supabase
          .from('availability')
          .insert({
            event_id: event.id,
            user_id: profile.id,
            player_id: playerId,
            status
          });
      }

      await loadAvailabilities();
      onUpdate?.();

      const player = linkedPlayers.find(p => p.id === playerId);
      toast({
        title: 'Status Updated',
        description: `${player?.full_name}'s availability has been set to ${status}`,
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update player availability',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const getPlayerStatus = (playerId: string): AvailabilityStatus => {
    const avail = playerAvailabilities.find((a) => a.player_id === playerId);
    return avail?.status || 'no_response';
  };

  const getStatusBadge = (status: AvailabilityStatus) => {
    switch (status) {
      case 'available':
        return (
          <Badge className="bg-green-500/20 text-green-700 dark:text-green-400 border-green-500/30">
            <Check className="w-3 h-3 mr-1" />
            Available
          </Badge>
        );
      case 'unavailable':
        return (
          <Badge className="bg-red-500/20 text-red-700 dark:text-red-400 border-red-500/30">
            <X className="w-3 h-3 mr-1" />
            Unavailable
          </Badge>
        );
      case 'maybe':
        return (
          <Badge className="bg-orange-500/20 text-orange-700 dark:text-orange-400 border-orange-500/30">
            <Clock className="w-3 h-3 mr-1" />
            Maybe
          </Badge>
        );
      default:
        return (
          <Badge className="bg-slate-500/20 text-slate-700 dark:text-slate-400 border-slate-500/30">
            <HelpCircle className="w-3 h-3 mr-1" />
            No Response
          </Badge>
        );
    }
  };

  const getAttendanceSummary = () => {
    const playerStatuses = allPlayers.map((player) => getPlayerStatus(player.id));

    return {
      available: playerStatuses.filter((s) => s === 'available').length,
      unavailable: playerStatuses.filter((s) => s === 'unavailable').length,
      maybe: playerStatuses.filter((s) => s === 'maybe').length,
      noResponse: playerStatuses.filter((s) => s === 'no_response').length,
    };
  };

  if (!event) return null;

  const isPast = new Date(event.event_date) < new Date();
  const summary = getAttendanceSummary();

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-900">
        <DialogHeader>
          <div className="flex items-center gap-3">
            {event.event_type === 'match' ? (
              <div className="p-2.5 rounded-xl bg-gradient-to-br from-red-500 to-red-600 text-white shadow-md">
                <Trophy className="w-5 h-5" />
              </div>
            ) : (
              <div className="p-2.5 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-md">
                <Dumbbell className="w-5 h-5" />
              </div>
            )}
            <div className="flex-1">
              <DialogTitle className="text-2xl font-bold">{event.title}</DialogTitle>
              {event.opponent && (
                <p className="text-sm text-slate-600 dark:text-slate-400">vs {event.opponent}</p>
              )}
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          <div className="space-y-3">
            <div className="flex items-center gap-3 text-slate-700 dark:text-slate-300">
              <Calendar className="w-5 h-5 flex-shrink-0" />
              <span className="font-medium">
                {format(new Date(event.event_date), 'EEEE, d MMMM yyyy • HH:mm')}
              </span>
            </div>

            <div className="flex items-center gap-3 text-slate-700 dark:text-slate-300">
              <MapPin className="w-5 h-5 flex-shrink-0" />
              <span>{event.location}</span>
            </div>

            {event.notes && (
              <div className="bg-slate-100 dark:bg-slate-800 rounded-xl p-4 mt-4">
                <p className="text-sm text-slate-600 dark:text-slate-400">{event.notes}</p>
              </div>
            )}
          </div>

          {profile?.role === 'manager' && (
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-xl p-4 border border-blue-200 dark:border-blue-800">
              <div className="flex items-center gap-2 mb-3">
                <Users className="w-5 h-5 text-blue-700 dark:text-blue-400" />
                <h3 className="font-semibold text-blue-900 dark:text-blue-100">
                  Attendance Summary
                </h3>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-2 text-sm">
                  <span className="w-3 h-3 rounded-full bg-green-500"></span>
                  <span className="text-slate-700 dark:text-slate-300">
                    <strong>{summary.available}</strong> Available
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="w-3 h-3 rounded-full bg-red-500"></span>
                  <span className="text-slate-700 dark:text-slate-300">
                    <strong>{summary.unavailable}</strong> Unavailable
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="w-3 h-3 rounded-full bg-orange-500"></span>
                  <span className="text-slate-700 dark:text-slate-300">
                    <strong>{summary.maybe}</strong> Maybe
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="w-3 h-3 rounded-full bg-slate-400"></span>
                  <span className="text-slate-700 dark:text-slate-300">
                    <strong>{summary.noResponse}</strong> No Response
                  </span>
                </div>
              </div>
            </div>
          )}

          {event.event_type === 'match' && lineup.length > 0 && (
            <div>
              <Tabs value={lineupTab} onValueChange={(v) => setLineupTab(v as 'list' | 'formation')}>
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="list" className="gap-2">
                    <Clipboard className="w-4 h-4" />
                    List View
                  </TabsTrigger>
                  <TabsTrigger value="formation" className="gap-2">
                    <Trophy className="w-4 h-4" />
                    Formation
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="list" className="space-y-4 mt-0">
                  {lineup.filter((p) => !p.is_substitute).length > 0 && (
                    <div className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 rounded-xl p-4 border border-green-200 dark:border-green-800">
                      <div className="flex items-center gap-2 mb-3">
                        <Clipboard className="w-5 h-5 text-green-700 dark:text-green-400" />
                        <h3 className="font-semibold text-green-900 dark:text-green-100">
                          Starting Lineup ({lineup.filter((p) => !p.is_substitute).length})
                        </h3>
                      </div>
                      <div className="space-y-2">
                        {lineup
                          .filter((p) => !p.is_substitute)
                          .map((player, index) => (
                            <div
                              key={player.player_id}
                              className="flex items-center gap-3 p-3 bg-white/60 dark:bg-slate-800/60 rounded-lg"
                            >
                              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center text-white font-bold text-sm">
                                {player.jersey_number || index + 1}
                              </div>
                              <div className="flex-1">
                                <p className="font-medium text-slate-900 dark:text-white">
                                  {player.player_name}
                                </p>
                                {player.position && (
                                  <p className="text-xs text-slate-600 dark:text-slate-400">
                                    {player.position}
                                  </p>
                                )}
                              </div>
                              <Badge className="bg-green-600 text-white">
                                Starter
                              </Badge>
                            </div>
                          ))}
                      </div>
                    </div>
                  )}

                  {lineup.filter((p) => p.is_substitute).length > 0 && (
                    <div className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 rounded-xl p-4 border border-orange-200 dark:border-orange-800">
                      <div className="flex items-center gap-2 mb-3">
                        <Users className="w-5 h-5 text-orange-700 dark:text-orange-400" />
                        <h3 className="font-semibold text-orange-900 dark:text-orange-100">
                          Substitutes ({lineup.filter((p) => p.is_substitute).length})
                        </h3>
                      </div>
                      <div className="space-y-2">
                        {lineup
                          .filter((p) => p.is_substitute)
                          .map((player, index) => (
                            <div
                              key={player.player_id}
                              className="flex items-center gap-3 p-3 bg-white/60 dark:bg-slate-800/60 rounded-lg"
                            >
                              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center text-white font-bold text-sm">
                                {player.jersey_number || index + 1}
                              </div>
                              <div className="flex-1">
                                <p className="font-medium text-slate-900 dark:text-white">
                                  {player.player_name}
                                </p>
                                {player.position && (
                                  <p className="text-xs text-slate-600 dark:text-slate-400">
                                    {player.position}
                                  </p>
                                )}
                              </div>
                              <Badge className="bg-orange-600 text-white">
                                Sub
                              </Badge>
                            </div>
                          ))}
                      </div>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="formation" className="mt-0">
                  <PitchFormation
                    selectedPlayers={lineup.filter((p) => !p.is_substitute).map((p) => p.player_id)}
                    allPlayers={lineup.map((p) => ({
                      id: p.player_id,
                      full_name: p.player_name,
                      jersey_number: p.jersey_number ?? undefined,
                      position: (p.position as 'Goalkeeper' | 'Defender' | 'Midfielder' | 'Forward' | undefined) ?? undefined,
                      date_of_birth: undefined,
                      parent_id: undefined,
                      avatar_url: undefined,
                      created_at: '',
                      updated_at: '',
                      created_by: '',
                    }))}
                    positions={lineup}
                    onPositionsChange={() => {}}
                    editable={false}
                  />
                </TabsContent>
              </Tabs>
            </div>
          )}

          {!isPast && (profile?.role === 'parent' || profile?.role === 'manager') && linkedPlayers.length > 0 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-slate-900 dark:text-white mb-3">
                  Player Availability
                </h3>
                <div className="space-y-3">
                  {linkedPlayers.map((player) => {
                    const playerStatus = getPlayerStatus(player.id);
                    return (
                      <div key={player.id} className="bg-slate-50 dark:bg-slate-800 rounded-xl p-4 border border-slate-200 dark:border-slate-700">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold shadow-md">
                            {player.jersey_number || player.full_name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                          </div>
                          <div className="flex-1">
                            <p className="font-semibold text-slate-900 dark:text-white">{player.full_name}</p>
                            {player.position && (
                              <p className="text-xs text-slate-600 dark:text-slate-400">{player.position}</p>
                            )}
                          </div>
                          {getStatusBadge(playerStatus)}
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <Button
                            size="sm"
                            onClick={() => updatePlayerAvailability(player.id, 'available')}
                            disabled={loading}
                            className={`transition-all duration-300 ${
                              playerStatus === 'available'
                                ? 'bg-green-600 hover:bg-green-700 text-white'
                                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-slate-300'
                            }`}
                          >
                            <Check className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => updatePlayerAvailability(player.id, 'maybe')}
                            disabled={loading}
                            className={`transition-all duration-300 ${
                              playerStatus === 'maybe'
                                ? 'bg-orange-600 hover:bg-orange-700 text-white'
                                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-slate-300'
                            }`}
                          >
                            <Clock className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => updatePlayerAvailability(player.id, 'unavailable')}
                            disabled={loading}
                            className={`transition-all duration-300 ${
                              playerStatus === 'unavailable'
                                ? 'bg-red-600 hover:bg-red-700 text-white'
                                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-slate-300'
                            }`}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {!isPast && ((profile?.role === 'parent' && !linkedPlayers.length) || (profile?.role === 'manager' && !linkedPlayers.length)) && (
            <div>
              <h3 className="font-semibold text-slate-900 dark:text-white mb-3">
                Your Availability
              </h3>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  onClick={() => updateAvailability('available')}
                  disabled={loading}
                  className={`h-auto py-3 transition-all duration-300 ${
                    userStatus === 'available'
                      ? 'bg-green-600 hover:bg-green-700 text-white shadow-lg scale-105'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300'
                  }`}
                >
                  <Check className="w-5 h-5 mr-2" />
                  Available
                </Button>

                <Button
                  onClick={() => updateAvailability('unavailable')}
                  disabled={loading}
                  className={`h-auto py-3 transition-all duration-300 ${
                    userStatus === 'unavailable'
                      ? 'bg-red-600 hover:bg-red-700 text-white shadow-lg scale-105'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300'
                  }`}
                >
                  <X className="w-5 h-5 mr-2" />
                  Unavailable
                </Button>

                <Button
                  onClick={() => updateAvailability('maybe')}
                  disabled={loading}
                  className={`h-auto py-3 transition-all duration-300 ${
                    userStatus === 'maybe'
                      ? 'bg-orange-600 hover:bg-orange-700 text-white shadow-lg scale-105'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300'
                  }`}
                >
                  <Clock className="w-5 h-5 mr-2" />
                  Maybe
                </Button>

                <Button
                  onClick={() => {
                    if (profile && availabilities.find((a) => a.user_id === profile.id)) {
                      supabase
                        .from('availability')
                        .delete()
                        .eq('event_id', event.id)
                        .eq('user_id', profile.id)
                        .then(() => {
                          setUserStatus('no_response');
                          loadAvailabilities();
                          onUpdate?.();
                        });
                    }
                  }}
                  disabled={loading}
                  className={`h-auto py-3 transition-all duration-300 ${
                    userStatus === 'no_response'
                      ? 'bg-slate-600 hover:bg-slate-700 text-white shadow-lg scale-105'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300'
                  }`}
                >
                  <HelpCircle className="w-5 h-5 mr-2" />
                  No Response
                </Button>
              </div>
            </div>
          )}

          <div>
            <h3 className="font-semibold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              <Users className="w-5 h-5" />
              Player Availability ({allPlayers.length})
            </h3>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {allPlayers.map((player) => {
                const status = getPlayerStatus(player.id);
                const isLinkedToUser = linkedPlayers.some(p => p.id === player.id);

                return (
                  <div
                    key={player.id}
                    className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-semibold text-sm shadow-md">
                        {player.jersey_number || player.full_name
                          .split(' ')
                          .map((n) => n[0])
                          .join('')
                          .toUpperCase()
                          .slice(0, 2)}
                      </div>
                      <div>
                        <p className="font-medium text-slate-900 dark:text-white">
                          {player.full_name}
                          {isLinkedToUser && (
                            <span className="ml-2 text-xs text-blue-600 dark:text-blue-400">
                              (Your child)
                            </span>
                          )}
                        </p>
                        <p className="text-xs text-slate-600 dark:text-slate-400">
                          {player.position || 'Player'} {player.jersey_number ? `• #${player.jersey_number}` : ''}
                        </p>
                      </div>
                    </div>
                    {getStatusBadge(status)}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
