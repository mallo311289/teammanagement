import { useState, useEffect } from 'react';
import { Event, Player, supabase } from '../../lib/supabase';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Checkbox } from '../ui/checkbox';
import { useToast } from '../../hooks/use-toast';
import { Loader2, Plus, Trash2, Trophy, Star, Heart } from 'lucide-react';

type MatchScoringModalProps = {
  event: Event | null;
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
};

type GoalEntry = {
  id?: string;
  player_id: string;
  assist_player_id?: string;
  goal_time?: number;
  is_own_goal?: boolean;
};

export function MatchScoringModal({ event, open, onClose, onSuccess }: MatchScoringModalProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(false);
  const [players, setPlayers] = useState<Player[]>([]);
  const [homeScore, setHomeScore] = useState<number>(0);
  const [awayScore, setAwayScore] = useState<number>(0);
  const [result, setResult] = useState<'win' | 'loss' | 'draw'>('draw');
  const [goals, setGoals] = useState<GoalEntry[]>([]);
  const [participants, setParticipants] = useState<string[]>([]);
  const [managersPlayer, setManagersPlayer] = useState<string>('');
  const [parentsPlayer, setParentsPlayer] = useState<string>('');

  useEffect(() => {
    if (open && event) {
      loadData();
    } else if (!open) {
      // Reset state when modal closes
      setHomeScore(0);
      setAwayScore(0);
      setResult('draw');
      setGoals([]);
      setParticipants([]);
      setManagersPlayer('');
      setParentsPlayer('');
    }
  }, [open, event]);

  const loadData = async () => {
    if (!event) return;

    setDataLoading(true);
    try {
      const [playersRes, goalsRes, participantsRes] = await Promise.all([
        supabase.from('players').select('*').order('full_name'),
        supabase.from('match_goals').select('*').eq('event_id', event.id),
        supabase.from('match_participants').select('*').eq('event_id', event.id),
      ]);

      if (playersRes.error) throw playersRes.error;

      setPlayers(playersRes.data || []);

      if (!goalsRes.error && goalsRes.data) {
        setGoals(goalsRes.data);
      }

      if (!participantsRes.error && participantsRes.data) {
        const participantData = participantsRes.data;
        setParticipants(participantData.filter(p => p.participated).map(p => p.player_id));

        const managersPick = participantData.find(p => p.is_managers_player);
        const parentsPick = participantData.find(p => p.is_parents_player);

        if (managersPick) setManagersPlayer(managersPick.player_id);
        if (parentsPick) setParentsPlayer(parentsPick.player_id);
      }

      setHomeScore(event.home_score || 0);
      setAwayScore(event.away_score || 0);
      setResult(event.result || 'draw');
    } catch (error) {
      // console.error('Error loading match data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load match data',
        variant: 'destructive',
      });
    } finally {
      setDataLoading(false);
    }
  };

  const addGoal = () => {
    setGoals([...goals, { player_id: '', assist_player_id: '', goal_time: undefined, is_own_goal: false }]);
  };

  const removeGoal = (index: number) => {
    setGoals(goals.filter((_, i) => i !== index));
  };

  const updateGoal = (index: number, field: keyof GoalEntry, value: any) => {
    const newGoals = [...goals];
    newGoals[index] = { ...newGoals[index], [field]: value };
    setGoals(newGoals);
  };

  const toggleParticipant = (playerId: string, checked: boolean) => {
    if (checked) {
      setParticipants([...participants, playerId]);
    } else {
      setParticipants(participants.filter(id => id !== playerId));
      // Clear player of match awards if player is removed from lineup
      if (managersPlayer === playerId) setManagersPlayer('');
      if (parentsPlayer === playerId) setParentsPlayer('');
    }
  };

  const handleSubmit = async () => {
    if (!event) return;

    try {
      setLoading(true);

      // Update event scores
      const { error: updateError } = await supabase
        .from('events')
        .update({
          home_score: homeScore,
          away_score: awayScore,
          result: result,
        })
        .eq('id', event.id);

      if (updateError) throw updateError;

      // Delete existing goals
      await supabase.from('match_goals').delete().eq('event_id', event.id);

      // Insert new goals
      const validGoals = goals.filter(g => g.player_id);
      if (validGoals.length > 0) {
        const { error: goalsError } = await supabase.from('match_goals').insert(
          validGoals.map(g => ({
            event_id: event.id,
            player_id: g.player_id,
            assist_player_id: g.assist_player_id && g.assist_player_id !== '' ? g.assist_player_id : null,
            goal_time: g.goal_time || null,
            is_own_goal: g.is_own_goal || false,
          }))
        );

        if (goalsError) throw goalsError;
      }

      // Delete existing participants
      await supabase.from('match_participants').delete().eq('event_id', event.id);

      // Insert new participants
      const participantRecords = participants.map(playerId => ({
        event_id: event.id,
        player_id: playerId,
        participated: true,
        is_managers_player: playerId === managersPlayer,
        is_parents_player: playerId === parentsPlayer,
      }));

      if (participantRecords.length > 0) {
        const { error: participantsError } = await supabase
          .from('match_participants')
          .insert(participantRecords);

        if (participantsError) throw participantsError;
      }

      toast({
        title: 'Success',
        description: 'Match details saved successfully',
      });

      onSuccess();
      onClose();
    } catch (error: any) {
      // console.error('Error saving match details:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to save match details',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (!event) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5" />
            Match Scoring - {event.title}
          </DialogTitle>
        </DialogHeader>

        {dataLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : (
          <>
            <div className="space-y-6 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="home_score">
                    {event.is_home_game ? 'Our Score' : 'Away Score'}
                  </Label>
                  <Input
                    id="home_score"
                    type="number"
                    value={homeScore}
                    onChange={(e) => setHomeScore(parseInt(e.target.value) || 0)}
                    min="0"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="away_score">
                    {event.is_home_game ? 'Opposition Score' : 'Home Score'}
                  </Label>
                  <Input
                    id="away_score"
                    type="number"
                    value={awayScore}
                    onChange={(e) => setAwayScore(parseInt(e.target.value) || 0)}
                    min="0"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="result">Result</Label>
                <Select value={result} onValueChange={(value: any) => setResult(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="win">Win</SelectItem>
                    <SelectItem value="draw">Draw</SelectItem>
                    <SelectItem value="loss">Loss</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Goalscorers</Label>
                  <Button type="button" variant="outline" size="sm" onClick={addGoal}>
                    <Plus className="w-4 h-4 mr-1" />
                    Add Goal
                  </Button>
                </div>

                {goals.length === 0 ? (
                  <p className="text-sm text-slate-500 text-center py-4">No goals added yet</p>
                ) : (
                  goals.map((goal, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex gap-2 items-end p-3 bg-slate-50 dark:bg-slate-900 rounded-lg">
                        <div className="flex-1 space-y-2">
                          <Label className="text-xs">Goal Scorer</Label>
                          <Select
                            value={goal.player_id}
                            onValueChange={(value) => updateGoal(index, 'player_id', value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select player" />
                            </SelectTrigger>
                            <SelectContent>
                              {players.map((player) => (
                                <SelectItem key={player.id} value={player.id}>
                                  {player.full_name} {player.jersey_number ? `#${player.jersey_number}` : ''}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="flex-1 space-y-2">
                          <Label className="text-xs">Assist</Label>
                          <Select
                            value={goal.assist_player_id || 'none'}
                            onValueChange={(value) => updateGoal(index, 'assist_player_id', value === 'none' ? undefined : value)}
                            disabled={goal.is_own_goal}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="No assist" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="none">No assist</SelectItem>
                              {players.map((player) => (
                                <SelectItem key={player.id} value={player.id}>
                                  {player.full_name} {player.jersey_number ? `#${player.jersey_number}` : ''}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="w-24 space-y-2">
                          <Label className="text-xs">Minute</Label>
                          <Input
                            type="number"
                            placeholder="Min"
                            value={goal.goal_time || ''}
                            onChange={(e) => updateGoal(index, 'goal_time', parseInt(e.target.value) || undefined)}
                            min="1"
                            max="120"
                          />
                        </div>

                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeGoal(index)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="flex items-center space-x-2 px-3">
                        <Checkbox
                          id={`own-goal-${index}`}
                          checked={goal.is_own_goal || false}
                          onCheckedChange={(checked) => {
                            updateGoal(index, 'is_own_goal', checked);
                            if (checked) {
                              updateGoal(index, 'assist_player_id', undefined);
                            }
                          }}
                          className="border-red-300 data-[state=checked]:bg-red-600 data-[state=checked]:border-red-600"
                        />
                        <label
                          htmlFor={`own-goal-${index}`}
                          className="text-sm font-medium leading-none cursor-pointer select-none text-red-600"
                        >
                          Own Goal
                        </label>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="space-y-3">
                <Label>Starting Lineup (Select Players Who Participated)</Label>
                <div className="grid grid-cols-2 gap-3 max-h-60 overflow-y-auto p-4 bg-slate-50 dark:bg-slate-900 rounded-lg border">
                  {players.length === 0 ? (
                    <p className="col-span-2 text-sm text-slate-500 text-center py-4">No players available</p>
                  ) : (
                    players.map((player) => (
                      <div key={player.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`participant-${player.id}`}
                          checked={participants.includes(player.id)}
                          onCheckedChange={(checked) => toggleParticipant(player.id, checked as boolean)}
                        />
                        <label
                          htmlFor={`participant-${player.id}`}
                          className="text-sm font-medium leading-none cursor-pointer select-none"
                        >
                          {player.full_name} {player.jersey_number ? `#${player.jersey_number}` : ''}
                        </label>
                      </div>
                    ))
                  )}
                </div>
                <p className="text-xs text-slate-500">
                  Selected: {participants.length} player{participants.length !== 1 ? 's' : ''}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-amber-500" />
                    Manager's Player of the Match
                  </Label>
                  <Select value={managersPlayer || 'none'} onValueChange={(value) => setManagersPlayer(value === 'none' ? '' : value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select player" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {players.filter(p => participants.includes(p.id)).map((player) => (
                        <SelectItem key={player.id} value={player.id}>
                          {player.full_name} {player.jersey_number ? `#${player.jersey_number}` : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Heart className="w-4 h-4 text-red-500" />
                    Parent's Player of the Match
                  </Label>
                  <Select value={parentsPlayer || 'none'} onValueChange={(value) => setParentsPlayer(value === 'none' ? '' : value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select player" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {players.filter(p => participants.includes(p.id)).map((player) => (
                        <SelectItem key={player.id} value={player.id}>
                          {player.full_name} {player.jersey_number ? `#${player.jersey_number}` : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button type="button" variant="outline" onClick={onClose} disabled={loading}>
                Cancel
              </Button>
              <Button onClick={handleSubmit} disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Save Match Details'
                )}
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
