import { useState, useRef, useEffect } from 'react';
import { Bell, MessageCircle, Calendar, Megaphone } from 'lucide-react';
import { useNotifications } from '../../contexts/NotificationContext';
import { NotificationBadge } from '../ui/notification-badge';
import { formatDistanceToNow } from 'date-fns';

type NotificationDropdownProps = {
  onNavigate: (tab: string) => void;
};

export function NotificationDropdown({ onNavigate }: NotificationDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotifications();

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleNotificationClick = async (notificationId: string, type: string) => {
    await markAsRead(notificationId);
    setIsOpen(false);

    if (type === 'message' || type === 'announcement') {
      onNavigate('chat');
    } else if (type === 'event') {
      onNavigate('home');
    }
  };

  const handleMarkAllRead = async () => {
    await markAllAsRead();
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'message':
        return <MessageCircle className="w-5 h-5 text-blue-600" />;
      case 'announcement':
        return <Megaphone className="w-5 h-5 text-orange-600" />;
      case 'event':
        return <Calendar className="w-5 h-5 text-green-600" />;
      default:
        return <Bell className="w-5 h-5 text-slate-600" />;
    }
  };

  const recentNotifications = notifications.slice(0, 10);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`relative w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 shadow-lg ${
          unreadCount > 0
            ? 'bg-white/20 hover:bg-white/30 ring-2 ring-white/40 hover:ring-white/60 hover:shadow-xl animate-pulse hover:animate-none hover:scale-105'
            : 'bg-white/10 hover:bg-white/20 ring-1 ring-white/20 hover:ring-white/40 hover:scale-105 hover:shadow-xl'
        }`}
      >
        <Bell className={`w-5 h-5 transition-all duration-300 ${
          unreadCount > 0 ? 'text-white fill-white drop-shadow-lg' : 'text-white/90 fill-white/90'
        }`} />
        <NotificationBadge count={unreadCount} />
      </button>

      {isOpen && (
        <div className="fixed sm:absolute top-16 sm:top-12 right-4 sm:right-0 left-4 sm:left-auto w-auto sm:w-96 bg-white rounded-xl sm:rounded-2xl shadow-2xl border border-slate-200 animate-in slide-in-from-top-2 duration-200 z-50 overflow-hidden">
          <div className="p-3 sm:p-4 border-b border-slate-200 flex items-center justify-between gap-2 bg-white">
            <h3 className="text-sm sm:text-lg font-bold text-slate-900">Notifications</h3>
            {unreadCount > 0 && (
              <button
                onClick={handleMarkAllRead}
                className="text-[11px] sm:text-sm text-[#4A6FA5] hover:text-[#3d5c8f] font-semibold whitespace-nowrap flex-shrink-0"
              >
                Mark all read
              </button>
            )}
          </div>

          <div className="max-h-[400px] sm:max-h-[500px] overflow-y-auto bg-slate-50/50">
            {recentNotifications.length === 0 ? (
              <div className="p-8 text-center bg-white">
                <Bell className="w-10 h-10 sm:w-12 sm:h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-sm sm:text-base text-slate-600 font-semibold">No notifications</p>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">You're all caught up!</p>
              </div>
            ) : (
              recentNotifications.map((notification) => (
                <button
                  key={notification.id}
                  onClick={() => handleNotificationClick(notification.id, notification.type)}
                  className={`w-full p-3 sm:p-4 text-left hover:bg-slate-100 active:bg-slate-200 transition-colors border-b border-slate-200 last:border-b-0 ${
                    !notification.is_read ? 'bg-blue-50' : 'bg-white'
                  }`}
                >
                  <div className="flex gap-2.5 sm:gap-3">
                    <div className="flex-shrink-0 mt-0.5">
                      {getNotificationIcon(notification.type)}
                    </div>
                    <div className="flex-1 min-w-0 pr-1">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <p className="text-[13px] sm:text-sm font-bold text-slate-900 line-clamp-2 break-words leading-snug">
                          {notification.title}
                        </p>
                        {!notification.is_read && (
                          <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0 mt-1.5" />
                        )}
                      </div>
                      <p className="text-[12px] sm:text-sm text-slate-700 line-clamp-3 mb-1.5 sm:mb-2 break-words leading-snug">
                        {notification.message}
                      </p>
                      <p className="text-[11px] sm:text-xs text-slate-500 font-medium">
                        {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>

          {recentNotifications.length > 0 && (
            <div className="p-3 border-t border-slate-200 text-center bg-white">
              <button
                onClick={() => setIsOpen(false)}
                className="text-sm text-slate-700 hover:text-slate-900 font-semibold"
              >
                Close
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
