import { WifiOff } from 'lucide-react';
import { useNetwork } from '../../contexts/NetworkContext';

export function NetworkStatus() {
  const { isOnline } = useNetwork();

  if (isOnline) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-red-500 text-white py-2 px-4 flex items-center justify-center gap-2 animate-in slide-in-from-top">
      <WifiOff className="w-4 h-4" />
      <span className="text-sm font-medium">No internet connection</span>
    </div>
  );
}
