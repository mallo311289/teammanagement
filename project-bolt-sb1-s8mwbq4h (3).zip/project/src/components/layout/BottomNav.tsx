import { Home, Users, Camera, Calendar, BarChart3, ClipboardList, MessageCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useNotifications } from '../../contexts/NotificationContext';
import { NotificationBadge } from '../ui/notification-badge';

type NavItem = {
  id: string;
  label: string;
  icon: React.ReactNode;
  roles?: ('manager' | 'parent')[];
};

const navItems: NavItem[] = [
  { id: 'home', label: 'Home', icon: <Home className="w-6 h-6" /> },
  { id: 'squad', label: 'Squad', icon: <Users className="w-6 h-6" /> },
  { id: 'fixtures', label: 'Fixtures', icon: <Calendar className="w-6 h-6" /> },
  { id: 'lineup', label: 'Lineups', icon: <ClipboardList className="w-6 h-6" /> },
  { id: 'chat', label: 'Chat', icon: <MessageCircle className="w-6 h-6" /> },
  { id: 'stats', label: 'Stats', icon: <BarChart3 className="w-6 h-6" /> },
  { id: 'media', label: 'Media', icon: <Camera className="w-6 h-6" /> },
];

type BottomNavProps = {
  activeTab: string;
  onTabChange: (tab: string) => void;
};

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  const { profile } = useAuth();
  const { messageUnreadCount, eventUnreadCount } = useNotifications();

  const filteredItems = navItems.filter(
    (item) => !item.roles || (profile && item.roles.includes(profile.role))
  );

  const getBadgeCount = (itemId: string) => {
    if (itemId === 'chat') return messageUnreadCount;
    if (itemId === 'home') return eventUnreadCount;
    return 0;
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#4A6FA5] border-t border-white/20 z-50 pb-[env(safe-area-inset-bottom)] shadow-lg">
      <div className="flex items-center justify-evenly px-1 py-3 max-w-full">
        {filteredItems.map((item) => {
          const isActive = activeTab === item.id;
          const badgeCount = getBadgeCount(item.id);

          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex flex-col items-center justify-center gap-1 px-2 py-2 rounded-xl transition-all duration-200 flex-1 min-w-0 max-w-[85px] touch-target-min active:scale-95 bg-[#5B7DB8] ${
                isActive
                  ? 'text-white shadow-md border-b-2 border-white'
                  : 'text-white/70'
              }`}
              style={{ flexShrink: 1, flexBasis: '0' }}
            >
              <div className={`relative transition-all duration-200 flex-shrink-0 ${isActive ? 'scale-110' : ''}`}>
                {item.icon}
                <NotificationBadge count={badgeCount} />
              </div>
              <span className={`text-[11px] whitespace-nowrap overflow-hidden text-ellipsis max-w-full block ${
                isActive ? 'font-bold' : 'font-medium'
              }`}>{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
