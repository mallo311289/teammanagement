import { useState } from 'react';
import { Shield, Mail, Lock, User } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../hooks/use-toast';

export function AuthScreen() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<'manager' | 'parent'>('parent');
  const [loading, setLoading] = useState(false);
  const { signIn, signUp } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isSignUp) {
        await signUp(email, password, fullName, role);
        toast({
          title: 'Success',
          description: 'Account created successfully!',
        });
      } else {
        await signIn(email, password);
        toast({
          title: 'Welcome back!',
          description: 'You have successfully signed in.',
          duration: 3000,
        });
      }
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Something went wrong',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#4A6FA5] via-[#5B7DB8] to-[#6B8BC3] flex flex-col items-center justify-center p-4 w-full">
      <div className="w-full max-w-md space-y-8 mx-auto">
        <div className="text-center space-y-6">
          <div className="flex justify-center">
            <div className="w-32 h-32 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center border-4 border-white/20">
              <Shield className="w-16 h-16 text-white" strokeWidth={1.5} />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-center gap-2">
              <Shield className="w-5 h-5 text-white/80" />
              <h1 className="text-2xl font-semibold text-white">TeamTrack</h1>
            </div>
            <p className="text-white/80 text-lg">Moorgreen Colts F.C.</p>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/20 shadow-2xl">
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-semibold text-white mb-2">
                {isSignUp ? 'Create Account' : 'Welcome Back'}
              </h2>
              <p className="text-white/70 text-sm">
                {isSignUp
                  ? 'Create a new account to get started'
                  : 'Sign in to your account or create a new one'}
              </p>
            </div>

            <div className="flex gap-2 bg-white/5 rounded-lg p-1">
              <button
                type="button"
                onClick={() => setIsSignUp(false)}
                className={`flex-1 py-2.5 rounded-md text-sm font-medium transition-all ${
                  !isSignUp
                    ? 'bg-white/20 text-white shadow-sm'
                    : 'text-white/70 hover:text-white'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => setIsSignUp(true)}
                className={`flex-1 py-2.5 rounded-md text-sm font-medium transition-all ${
                  isSignUp
                    ? 'bg-white/20 text-white shadow-sm'
                    : 'text-white/70 hover:text-white'
                }`}
              >
                Sign Up
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {isSignUp && (
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="text-white text-sm">
                    Full Name
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50" />
                    <Input
                      id="fullName"
                      type="text"
                      placeholder="John Smith"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      required
                      className="pl-10 bg-white/5 border-white/20 text-white placeholder:text-white/40 focus:bg-white/10 h-12 w-full"
                      autoComplete="name"
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="email" className="text-white text-sm">
                  Email
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="pl-10 bg-white/5 border-white/20 text-white placeholder:text-white/40 focus:bg-white/10 h-12 w-full"
                    autoComplete="email"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-white text-sm">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={6}
                    className="pl-10 bg-white/5 border-white/20 text-white placeholder:text-white/40 focus:bg-white/10 h-12 w-full"
                    autoComplete="current-password"
                  />
                </div>
              </div>

              {isSignUp && (
                <div className="space-y-2">
                  <Label className="text-white text-sm">Role</Label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setRole('parent')}
                      className={`flex-1 py-3 rounded-lg text-sm font-medium transition-all ${
                        role === 'parent'
                          ? 'bg-[#2ECC71] text-white shadow-lg'
                          : 'bg-white/5 text-white/70 hover:bg-white/10'
                      }`}
                    >
                      Parent
                    </button>
                    <button
                      type="button"
                      onClick={() => setRole('manager')}
                      className={`flex-1 py-3 rounded-lg text-sm font-medium transition-all ${
                        role === 'manager'
                          ? 'bg-[#2ECC71] text-white shadow-lg'
                          : 'bg-white/5 text-white/70 hover:bg-white/10'
                      }`}
                    >
                      Manager
                    </button>
                  </div>
                </div>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="w-full h-12 bg-white text-[#4A6FA5] hover:bg-white/90 font-medium text-base shadow-lg"
              >
                {loading ? 'Please wait...' : isSignUp ? 'Create Account' : 'Sign In'}
              </Button>
            </form>
          </div>
        </div>

        <p className="text-center text-white/60 text-sm">
          Empowering teams, one match at a time
        </p>
      </div>
    </div>
  );
}
